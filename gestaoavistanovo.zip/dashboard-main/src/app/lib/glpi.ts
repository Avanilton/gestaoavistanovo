
'use server';

function createFetchError(error: Error, url: string): Error {
    if (error.message.toLowerCase().includes('fetch failed')) {
        if (url.startsWith('http://')) {
            return new Error(`A URL da API GLPI (${url}) usa 'http'. O ambiente de produção pode estar bloqueando conexões não seguras. Verifique se a API está acessível via 'https' e atualize a variável de ambiente. Detalhe: ${error.message}`);
        }
        return new Error(`Falha de rede ao conectar à API GLPI (${url}). Verifique se a URL está correta e acessível a partir do servidor. Detalhe: ${error.message}`);
    }
    return error;
}


async function getSessionToken(): Promise<string> {
    const apiUrl = process.env.GLPI_API_URL;
    const userToken = process.env.GLPI_USER_TOKEN;
    const appToken = process.env.GLPI_APP_TOKEN;

    if (!apiUrl || !userToken || !appToken) {
        throw new Error('As variáveis de ambiente da API GLPI (URL, User Token, App Token) não estão configuradas.');
    }
    
    // A URL para iniciar a sessão é a base da API + /initSession
    const initSessionUrl = new URL('initSession', apiUrl.endsWith('/') ? apiUrl : apiUrl + '/');

    try {
        const response = await fetch(initSessionUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `user_token ${userToken}`,
                'App-Token': appToken,
            },
            // Desabilita o cache para garantir um novo token de sessão sempre que necessário
            cache: 'no-store',
        });
        
        if (!response.ok) {
            const errorBody = await response.json().catch(() => ({ message: 'Erro desconhecido ao ler corpo do erro.' }));
            console.error('GLPI initSession Error Body:', errorBody);
            throw new Error(`Falha ao iniciar sessão no GLPI. Status: ${response.status}. Verifique as credenciais e a URL.`);
        }

        const data = await response.json();
        
        if (!data.session_token) {
            throw new Error('Token de sessão não foi retornado pela API GLPI.');
        }
        
        return data.session_token;

    } catch (error) {
        console.error('Erro em getSessionToken:', error);
        if (error instanceof Error) {
            throw createFetchError(error, apiUrl);
        }
        throw new Error('Ocorreu um erro desconhecido ao tentar obter o token de sessão do GLPI.');
    }
}


export async function glpiApiRequest<T>(endpoint: string, params: Record<string, any> = {}): Promise<T> {
  const apiUrl = process.env.GLPI_API_URL;
  const appToken = process.env.GLPI_APP_TOKEN;
  
  if (!apiUrl || !appToken) {
    throw new Error('As variáveis de ambiente GLPI_API_URL e GLPI_APP_TOKEN não estão configuradas.');
  }

  // Obtém o token de sessão antes de fazer a requisição
  const sessionToken = await getSessionToken();
  
  const finalUrl = new URL(endpoint.startsWith('/') ? endpoint.substring(1) : endpoint, apiUrl.endsWith('/') ? apiUrl : apiUrl + '/');

  Object.keys(params).forEach(key => finalUrl.searchParams.append(key, params[key]));

  try {
    const response = await fetch(finalUrl.toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Session-Token': sessionToken,
        'App-Token': appToken,
      },
      next: { revalidate: 14400 }, // Revalida os dados a cada 4 horas
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error(`GLPI API Error on ${endpoint}:`, response.status, errorBody);
      throw new Error(`Falha de conexão ao tentar buscar dados do GLPI em ${finalUrl.pathname}. Status: ${response.status}. Verifique a rede e a URL da API.`);
    }
    
    // Se a resposta estiver vazia (ex: 204 No Content), retorna um array vazio
    if (response.status === 204 || response.headers.get('Content-Length') === '0') {
      return [] as T;
    }
    
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
        return await response.json();
    } else {
        // Se a resposta não for JSON, retorna um array vazio para evitar quebrar a aplicação
        const textResponse = await response.text();
        console.warn(`Resposta da API GLPI não é JSON para ${endpoint}:`, textResponse);
        return [] as T;
    }
    
  } catch (error) {
    console.error(`Falha ao buscar dados do GLPI no endpoint ${endpoint}:`, error);
    if (error instanceof Error) {
        throw createFetchError(error, apiUrl);
    }
    throw new Error(`Ocorreu um erro desconhecido ao buscar dados do GLPI em ${endpoint}.`);
  }
}
