import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { CicloPedidoCard } from "@/components/dashboard-logistica/ciclo-pedido-card";
import { StockoutCard } from "@/components/dashboard-logistica/stockout-card";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";

export const dynamic = 'force-dynamic';

export default function DashboardLogisticaPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Dashboard de Logística</h2>
          <DataSourceLabel source="API - Sankhya" />
        </div>
        <div className="grid gap-4 md:grid-cols-1 md:gap-8 lg:grid-cols-2">
            <CicloPedidoCard />
            <StockoutCard />
        </div>
      </main>
    </div>
  );
}
