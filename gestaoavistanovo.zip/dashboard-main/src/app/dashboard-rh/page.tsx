import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { RetentionCard } from "@/components/dashboard-rh/retention-card";
import { GestaoAtivaCard } from "@/components/dashboard-rh/gestao-ativa-card";
import { InternalNpsCard } from "@/components/dashboard-rh/internal-nps-card";
import { AbsenteeismCard } from "@/components/dashboard-rh/absenteeism-card";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";
import { SlaRecrutamentoCard } from "@/components/dashboard-rh/sla-recrutamento-card";

export const dynamic = 'force-dynamic';

export default function DashboardRhPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Dashboard de RH</h2>
          <DataSourceLabel source="Lançamento Manual - Sankhya" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
          <RetentionCard />
          <InternalNpsCard />
          <SlaRecrutamentoCard />
        </div>
        <div className="grid gap-4 md:grid-cols-1 md:gap-8 lg:grid-cols-2">
          <AbsenteeismCard />
          <GestaoAtivaCard />
        </div>
      </main>
    </div>
  );
}
