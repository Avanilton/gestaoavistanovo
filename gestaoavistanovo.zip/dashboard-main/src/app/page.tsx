
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default function LandingPage() {
  // Redireciona diretamente para o primeiro dashboard funcional
  redirect('/dashboard-ti');
}
