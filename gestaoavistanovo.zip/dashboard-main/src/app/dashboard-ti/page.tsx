'use client';

import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { ProjectsCard } from "@/components/dashboard/projects-card";
import { SlaAtendimentosCard } from "@/components/dashboard/sla-atendimentos-card";
import { GlpiTicketsByStatusCard } from "@/components/dashboard/glpi-tickets-by-status-card";
import { NeuralBackground } from "@/components/ui/neural-background";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";

export const dynamic = 'force-dynamic';

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background relative">
      <NeuralBackground />
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 z-10">
        <DataSourceLabel source="API - Glpi" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
            <ProjectsCard />
            <SlaAtendimentosCard />
        </div>
        <div className="grid gap-4 md:grid-cols-1 md:gap-8 lg:grid-cols-1">
            <GlpiTicketsByStatusCard />
        </div>
      </main>
    </div>
  );
}
