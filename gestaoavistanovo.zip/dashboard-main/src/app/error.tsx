"use client"; // Os componentes de erro devem ser "Client Components"

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Loga o erro em um serviço de reporte de erros
    console.error(error);
  }, [error]);

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-background p-4">
      <Card className="w-full max-w-lg text-center">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-destructive">Ocorreu um Erro no Servidor</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-muted-foreground">
            A aplicação encontrou um problema inesperado. Por favor, tente novamente. Se o problema persistir, entre em contato com o suporte.
          </p>
          {/* Exibe os detalhes do erro para fins de depuração */}
          <details className="mt-4 rounded-lg bg-muted p-3 text-left text-xs">
            <summary className="cursor-pointer font-medium">Detalhes do Erro (para desenvolvedores)</summary>
            <pre className="mt-2 whitespace-pre-wrap break-words font-mono text-muted-foreground">
              {error.message}
              {error.stack && `\n\nStack:\n${error.stack}`}
            </pre>
          </details>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button onClick={() => reset()}>Tentar Novamente</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
