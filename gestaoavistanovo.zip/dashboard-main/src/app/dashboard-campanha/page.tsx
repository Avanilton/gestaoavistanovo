
import Image from 'next/image';
import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";

export const dynamic = 'force-dynamic';

export default function CampanhaPage() {
  const imageUrl = "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Mulher.png?alt=media";

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col items-center justify-center p-4 md:p-8">
        <div className="relative w-full h-[calc(100vh-120px)] rounded-xl overflow-hidden shadow-2xl bg-card border">
          <Image
            src={imageUrl}
            alt="Campanha Mulher"
            fill
            className="object-contain"
            priority
            unoptimized
          />
        </div>
      </main>
    </div>
  );
}
