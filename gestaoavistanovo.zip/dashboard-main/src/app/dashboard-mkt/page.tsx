import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { TicketMedioCard } from "@/components/dashboard-mkt/ticket-medio-card";
import { CacCard } from "@/components/dashboard-mkt/cac-card";
import { TaxaConversaoCard } from "@/components/dashboard-mkt/taxa-conversao-card";
import { AtividadesTimeCard } from "@/components/dashboard-mkt/atividades-time-card";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";

export const dynamic = 'force-dynamic';

export default function DashboardMktPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Dashboard de Marketing</h2>
          <DataSourceLabel source="Lançamento Manual - Sankhya" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4">
            <TicketMedioCard />
            <CacCard />
            <TaxaConversaoCard />
            <AtividadesTimeCard />
        </div>
      </main>
    </div>
  );
}
