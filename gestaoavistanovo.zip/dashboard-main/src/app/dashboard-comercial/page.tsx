'use client';

import { useState, useEffect } from "react";
import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { getComercialData, type SankhyaTeamData } from "@/app/actions/sankhya-actions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AlertTriangle, Briefcase } from "lucide-react";
import { EquipeIndicadoresRow } from "@/components/dashboard-comercial/equipe-indicadores-row";
import { Separator } from "@/components/ui/separator";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";
import { Skeleton } from "@/components/ui/skeleton";

type IndicadoresEquipe = {
    percentual: number;
    dm: number;
    pmf: number;
    mix: number;
    clientesAtendidos: number;
};

export default function DashboardComercialPage() {
    const [desempenhoData, setDesempenhoData] = useState<SankhyaTeamData[] | undefined>(undefined);
    const [error, setError] = useState<any | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(true);
    const [updateTimestamp, setUpdateTimestamp] = useState(Date.now());

    useEffect(() => {
        async function fetchData() {
            setIsLoading(true);
            try {
                const { data, error } = await getComercialData();
                if (error) {
                    setError(error);
                } else {
                    setDesempenhoData(data);
                }
            } catch (e: any) {
                setError(e.message || "Erro desconhecido");
            } finally {
                setUpdateTimestamp(Date.now());
                setIsLoading(false);
            }
        }
        fetchData();
    }, []);


    let externoData: IndicadoresEquipe | undefined;
    let internoData: IndicadoresEquipe | undefined;
    let bronzeData: IndicadoresEquipe | undefined;

    if (desempenhoData) {
        const equipesExternas = desempenhoData.filter(d => d.CODEQUIPE === '1' || d.CODEQUIPE === '3');
        const equipeInterna = desempenhoData.find(d => d.CODEQUIPE === '4');
        const equipeBronze = desempenhoData.find(d => d.CODEQUIPE === '5');

        if (equipesExternas.length > 0) {
            externoData = {
                percentual: equipesExternas.reduce((acc, e) => acc + e.PERCENTUAL, 0) / equipesExternas.length,
                dm: equipesExternas.reduce((acc, e) => acc + e.DM, 0) / equipesExternas.length,
                pmf: equipesExternas.reduce((acc, e) => acc + e.PMF, 0) / equipesExternas.length,
                mix: equipesExternas.reduce((acc, e) => acc + e.MIX, 0) / equipesExternas.length,
                clientesAtendidos: equipesExternas.reduce((acc, e) => acc + e.CLIENTES_ATENDIDOS, 0),
            };
        }
        
        if (equipeInterna) {
            internoData = {
                percentual: equipeInterna.PERCENTUAL,
                dm: equipeInterna.DM,
                pmf: equipeInterna.PMF,
                mix: equipeInterna.MIX,
                clientesAtendidos: equipeInterna.CLIENTES_ATENDIDOS,
            };
        }

        if (equipeBronze) {
            bronzeData = {
                percentual: equipeBronze.PERCENTUAL,
                dm: equipeBronze.DM,
                pmf: equipeBronze.PMF,
                mix: equipeBronze.MIX,
                clientesAtendidos: equipeBronze.CLIENTES_ATENDIDOS,
            };
        }
    }

    const renderLoadingState = () => (
        <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
                <Card key={i} className="w-full">
                    <CardHeader>
                        <Skeleton className="h-8 w-1/3" />
                        <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                            {[...Array(5)].map((_, j) => (
                                <Skeleton key={j} className="h-36 w-full" />
                            ))}
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );

    return (
        <div className="flex min-h-screen w-full flex-col bg-background">
            <AutoPageSwitcher />
            <AutoRefresher />
            <Header />
            <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Briefcase className="h-8 w-8" />
                        <h1 className="text-4xl font-bold tracking-tight">Dashboard Comercial</h1>
                    </div>
                    <DataSourceLabel source="API - Sankhya" />
                </div>

                {isLoading ? renderLoadingState() : error ? (
                     <Card className="col-span-full">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-destructive">
                                <AlertTriangle />
                                Falha ao Carregar Dados Comerciais
                            </CardTitle>
                             <CardDescription>
                                Ocorreu um erro ao buscar os dados da API Sankhya. Os indicadores não puderam ser renderizados.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                           
                            <p className="text-sm text-destructive-foreground bg-destructive/80 p-3 rounded-md">
                                Detalhe: {typeof error === 'string' ? error : JSON.stringify(error)}
                            </p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="space-y-6">
                        {externoData && (
                            <EquipeIndicadoresRow 
                                title="Comercial Externo"
                                percentual={externoData.percentual}
                                dm={externoData.dm}
                                pmf={externoData.pmf}
                                mix={externoData.mix}
                                clientesAtendidos={externoData.clientesAtendidos}
                                updateTimestamp={updateTimestamp}
                            />
                        )}
                        
                        <Separator />

                        {internoData && (
                             <EquipeIndicadoresRow 
                                title="Comercial Interno"
                                percentual={internoData.percentual}
                                dm={internoData.dm}
                                pmf={internoData.pmf}
                                mix={internoData.mix}
                                clientesAtendidos={internoData.clientesAtendidos}
                                updateTimestamp={updateTimestamp}
                            />
                        )}

                        <Separator />

                        {bronzeData && (
                            <EquipeIndicadoresRow 
                                title="Comercial Bronze"
                                percentual={bronzeData.percentual}
                                dm={bronzeData.dm}
                                pmf={bronzeData.pmf}
                                mix={bronzeData.mix}
                                clientesAtendidos={bronzeData.clientesAtendidos}
                                updateTimestamp={updateTimestamp}
                            />
                        )}
                    </div>
                )}
            </main>
        </div>
    );
}
