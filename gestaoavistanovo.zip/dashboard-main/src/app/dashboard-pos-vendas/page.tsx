'use client';

import { useState, useEffect } from "react";
import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { ChamadosAbertosCard } from "@/components/dashboard-pos-vendas/chamados-abertos-card";
import { OcorrenciasTransportadoresCard } from "@/components/dashboard-pos-vendas/ocorrencias-transportadores-card";
import { AtendimentoWhatsAppCard } from "@/components/dashboard-pos-vendas/atendimento-whatsapp-card";
import { OcorrenciasPorSetorCard } from "@/components/dashboard-pos-vendas/ocorrencias-por-setor-card";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";
import { getPosVendasSankhyaData, type PosVendasSankhyaData } from "@/app/actions/pos-vendas-data-actions";
import { Skeleton } from "@/components/ui/skeleton";

export default function DashboardPosVendasPage() {
  const [data, setData] = useState<PosVendasSankhyaData | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
        setIsLoading(true);
        const { data, error } = await getPosVendasSankhyaData();
        if (error) {
            setError(error);
        } else {
            setData(data);
        }
        setIsLoading(false);
    }
    fetchData();
  }, []);

  if (isLoading) {
    return (
        <div className="flex min-h-screen w-full flex-col bg-background">
            <AutoPageSwitcher />
            <AutoRefresher />
            <Header />
            <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold tracking-tight">Indicadores - Pós Vendas</h2>
                    <DataSourceLabel source="API - Sankhya" />
                </div>
                <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-48 w-full" />
                </div>
                <div className="grid gap-4 md:grid-cols-1">
                    <Skeleton className="h-96 w-full" />
                </div>
            </main>
        </div>
    );
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Indicadores - Pós Vendas</h2>
          <DataSourceLabel source="API - Sankhya" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
            <ChamadosAbertosCard initialData={data} error={error} />
            <OcorrenciasTransportadoresCard initialData={data} error={error} />
            <AtendimentoWhatsAppCard initialData={data} error={error} />
        </div>
        <div className="grid gap-4 md:grid-cols-1">
            <OcorrenciasPorSetorCard initialData={data} error={error} />
        </div>
      </main>
    </div>
  );
}
