import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { ProducaoBlistersCard } from "@/components/dashboard-tecnica/producao-blisters-card";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";
import { ItensNovosCard } from "@/components/dashboard-tecnica/itens-novos-card";

export const dynamic = 'force-dynamic';

export default function DashboardTecnicaPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Dashboard Técnica</h2>
          <DataSourceLabel source="Lançamento Manual" />
        </div>
        <div className="grid gap-4 md:grid-cols-1">
          <ItensNovosCard />
        </div>
        <div className="grid gap-4 md:grid-cols-1">
           <ProducaoBlistersCard />
        </div>
      </main>
    </div>
  );
}
