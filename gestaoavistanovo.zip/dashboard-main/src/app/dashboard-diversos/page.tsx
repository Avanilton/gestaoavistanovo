
'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";
import { cn } from "@/lib/utils";

const images = [
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FCristina%20Junqueira.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Claudiceia.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Giovanna.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Zulmira.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Amanda%201.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Carol.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Diogo.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Ana%20Vitorino.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Luiz.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Fran%201.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Milene.png?alt=media",
  "https://firebasestorage.googleapis.com/v0/b/studio-7090649363-3ec14.firebasestorage.app/o/Dia%20da%20mulher%2FRecado%20Kerolin.png?alt=media",
];

const ROTATION_INTERVAL = 20000; // 20 segundos por imagem

export default function DiversosPage() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (images.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, ROTATION_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col items-center justify-center p-4 md:p-8">
        <div className="relative w-full h-[calc(100vh-120px)] rounded-xl overflow-hidden shadow-2xl bg-card border">
          {images.map((src, index) => (
            <div
              key={src}
              className={cn(
                "absolute inset-0 transition-opacity duration-1000 ease-in-out",
                index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
              )}
            >
              <Image
                src={src}
                alt={`Diversos - Imagem ${index + 1}`}
                fill
                className="object-contain"
                priority={index === 0}
                unoptimized
              />
            </div>
          ))}
          
          {images.length > 1 && (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-wrap justify-center gap-2 z-20 bg-black/20 backdrop-blur-sm px-4 py-2 rounded-full max-w-[90%]">
              {images.map((_, index) => (
                <div
                  key={index}
                  className={cn(
                    "h-2.5 w-2.5 rounded-full transition-all duration-300",
                    index === currentIndex ? "bg-primary w-8" : "bg-white/50"
                  )}
                />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
