
'use server';

export type InadimplenciaData = {
    mesReferencia: string;
    geral: string;
    externo: string;
    interno: string;
    bronze: string;
    acumulado12M: string;
};

function robustParseCsv(csvText: string): string[][] {
    const lines = csvText.trim().split('\n');
    return lines.map(line => {
        const result: string[] = [];
        let currentField = '';
        let inQuotes = false;

        const processedLine = line + ',';

        for (let i = 0; i < processedLine.length; i++) {
            const char = processedLine[i];

            if (char === '"' && (i === 0 || processedLine[i - 1] !== '\\')) {
                 inQuotes = !inQuotes;
                 currentField += char;
            } else if (char === ',' && !inQuotes) {
                let finalField = currentField.trim();
                if (finalField.startsWith('"') && finalField.endsWith('"')) {
                    finalField = finalField.substring(1, finalField.length - 1);
                }
                result.push(finalField);
                currentField = '';
            } else {
                currentField += char;
            }
        }
        return result;
    });
}


export async function getInadimplenciaData(): Promise<{ data?: InadimplenciaData; error?: string }> {
    const sheetUrl = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vQ_3004vIdS1LTvvhEh_1H3Uud_OUESdXPd8zAfs5XJ7_LcQULJURJj9VzWG3OAkFburlLnNvSnzS-X/pub?gid=0&single=true&output=csv';

    try {
        const response = await fetch(sheetUrl, { next: { revalidate: 1800 } });
        if (!response.ok) {
            throw new Error(`Falha ao buscar a planilha (GID: 0): ${response.status} ${response.statusText}`);
        }
        const csvText = await response.text();
        const allRows = robustParseCsv(csvText);
        
        const nonEmptyRows = allRows.filter(row => row.some(cell => cell.trim() !== ''));

        if (nonEmptyRows.length < 2) { 
             throw new Error('Não há dados suficientes na planilha de Inadimplência.');
        }

        const lastRow = nonEmptyRows[nonEmptyRows.length - 1];

        const rowForAcumulado = allRows[1];

        if (!lastRow) {
            throw new Error(`Não foi encontrada a última linha com dados na planilha.`);
        }
        if (!rowForAcumulado) {
            throw new Error(`Não foi encontrada a linha 2 para o "Acumulado do Ano".`);
        }
        
        if (lastRow.length < 5 || rowForAcumulado.length < 6) {
             throw new Error('A estrutura da planilha parece inválida. Alguma coluna pode estar faltando na última linha ou na linha 2.');
        }

        const inadimplenciaData: InadimplenciaData = {
            mesReferencia: lastRow[0] || 'N/A', // Mês está na primeira coluna
            geral: lastRow[1] || '0%',
            externo: lastRow[2] || '0%',
            interno: lastRow[3] || '0%',
            bronze: lastRow[4] || '0%',
            acumulado12M: rowForAcumulado[5] || '0%',
        };

        return { data: inadimplenciaData };

    } catch (error) {
        console.error("Erro ao buscar ou processar dados de Inadimplência:", error);
        const errorMessage = error instanceof Error ? error.message : "Não foi possível carregar os dados de Inadimplência.";
        return { error: errorMessage };
    }
}
