
'use server';

import { sankhyaApiRequest } from "./sankhya-actions";
import { format, parse } from "date-fns";
import { ptBR } from "date-fns/locale";


export type PosVendasSankhyaData = {
    chamadosAbertos: number;
    totalOcorrencias: number;
    tempoMedioAtendimento: string;
    ocorrenciasPorSetor: { name: string; value: number }[];
    mesReferencia: string;
};

const extractValue = (field: any): string => {
    if (field && typeof field === 'object' && '$' in field) {
        return field['$'];
    }
    if (field !== null && field !== undefined) {
        return String(field);
    }
    return '0';
};

const toNumber = (value: string): number => {
    if (!value) return 0;
    const parsed = parseFloat(value.replace(',', '.'));
    return isNaN(parsed) ? 0 : parsed;
};

const sectorMap: { [key: string]: string } = {
    '1': 'ADM',
    '2': 'EXTERNO',
    '3': 'INTERNO',
    '4': 'FINANCEIRO',
    '5': 'LOGÍSTICA',
    '6': 'MARKETING',
    '7': 'TÉCNICA',
    '8': 'TI',
    '9': 'Garantia',
    '10': 'Diversos',
};

const parseDate = (dateString: string): Date => {
    return parse(dateString, 'dd/MM/yyyy HH:mm:ss', new Date());
};


export async function getPosVendasSankhyaData(): Promise<{ data?: PosVendasSankhyaData, error?: string }> {
    try {
        // Busca os dados das duas views em paralelo
        const [resumoResult, setorResult] = await Promise.all([
            sankhyaApiRequest("VW_POSVENDAS", ["CHAMADOS", "OCORRENCIA", "ATENDIMENTO"]),
            sankhyaApiRequest("VW_LANCAMENTOSPOSVENDAS", ["SETOR", "QTDOCO", "PERIODO"])
        ]);

        if (resumoResult.error) {
            throw new Error(`Erro ao buscar VW_POSVENDAS: ${resumoResult.error}`);
        }
        if (setorResult.error) {
            throw new Error(`Erro ao buscar VW_LANCAMENTOSPOSVENDAS: ${setorResult.error}`);
        }

        // --- Processa os dados de resumo (VW_POSVENDAS) ---
        const resumoRecord = resumoResult.data?.record?.[0];
        if (!resumoRecord) {
            throw new Error("Nenhum registro de resumo encontrado em VW_POSVENDAS.");
        }
        const chamadosAbertos = toNumber(extractValue(resumoRecord.CHAMADOS));
        const totalOcorrencias = toNumber(extractValue(resumoRecord.OCORRENCIA));
        const tempoMedioAtendimento = extractValue(resumoRecord.ATENDIMENTO);


        // --- Processa os dados por setor (VW_LANCAMENTOSPOSVENDAS) ---
        let setorRecords = setorResult.data?.record;
        if (!setorRecords || setorRecords.length === 0) {
            throw new Error("Nenhum registro de setor encontrado em VW_LANCAMENTOSPOSVENDAS.");
        }
        
        // Garante que setorRecords seja sempre um array
        if (!Array.isArray(setorRecords)) {
            setorRecords = [setorRecords];
        }
        
        // Ordena para pegar o registro mais recente
        setorRecords.sort((a: any, b: any) => {
            const dateA = parseDate(extractValue(a.PERIODO));
            const dateB = parseDate(extractValue(b.PERIODO));
            return dateB.getTime() - dateA.getTime();
        });


        // --- Processa o mês de referência e filtra os dados do mês mais recente ---
        let mesReferencia = "N/A";
        const registroMaisRecente = setorRecords[0];
        const periodoStr = extractValue(registroMaisRecente?.PERIODO);
        let registrosDoMesAtual: any[] = [];

        if (periodoStr) {
            const latestDate = parseDate(periodoStr);
            if (!isNaN(latestDate.getTime())) {
                mesReferencia = format(latestDate, "MMMM / yyyy", { locale: ptBR });
                
                // Filtra para manter apenas os registros do mesmo mês e ano do mais recente
                registrosDoMesAtual = setorRecords.filter((record: any) => {
                    const recordDate = parseDate(extractValue(record.PERIODO));
                    return !isNaN(recordDate.getTime()) &&
                           recordDate.getMonth() === latestDate.getMonth() &&
                           recordDate.getFullYear() === latestDate.getFullYear();
                });
            } else {
                 registrosDoMesAtual = setorRecords; // fallback para usar todos se a data for inválida
            }
        } else {
            registrosDoMesAtual = setorRecords; // fallback
        }
        
        const ocorrenciasPorSetor = registrosDoMesAtual.map((record: any) => {
            const setorId = extractValue(record.SETOR);
            const setorNome = sectorMap[setorId] || `Setor ${setorId}`;
            return {
                name: setorNome,
                value: toNumber(extractValue(record.QTDOCO)),
            };
        }).filter((item: { name: string; value: number }) => item.value > 0);
        
        const result: PosVendasSankhyaData = {
            chamadosAbertos,
            totalOcorrencias,
            tempoMedioAtendimento,
            ocorrenciasPorSetor,
            mesReferencia,
        };

        return { data: result };

    } catch (error) {
        console.error("Erro ao buscar ou processar dados de Pós Vendas do Sankhya:", error);
        const errorMessage = error instanceof Error ? error.message : "Não foi possível carregar os dados de Pós Vendas.";
        return { error: errorMessage };
    }
}
