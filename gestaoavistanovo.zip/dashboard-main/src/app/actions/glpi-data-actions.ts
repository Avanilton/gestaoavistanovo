
'use server';
import { glpiApiRequest } from "@/app/lib/glpi";
import { format, startOfMonth, endOfMonth, setMonth, getYear } from 'date-fns';

export type ProjectData = {
  id: number;
  name: string;
  date: string;
  priority: number;
  percentDone: number;
};

function createGlpiErrorMessage(error: unknown, context: string): string {
    console.error(`Falha ao buscar dados do GLPI (${context}):`, error);
    if (error instanceof Error) {
        return error.message;
    }
    return `Ocorreu um erro desconhecido ao buscar ${context}.`;
}

export async function getProjectsData(): Promise<{ data?: ProjectData[], error?: string }> {
  try {
    const projects = await glpiApiRequest<any[]>('/Project', {
      is_deleted: '0',
      'criteria[0][field]': 'status',
      'criteria[0][searchtype]': 'equals',
      'criteria[0][value]': '1', // Apenas projetos "Em andamento"
      sort: 'priority',
      order: 'DESC',
      range: '0-10', // Limita aos 10 projetos mais prioritários
    });

    const result = projects.map(p => ({
      id: p.id,
      name: p.name,
      date: p.plan_start_date,
      priority: p.priority,
      percentDone: p.percent_done || 0,
    }));
    return { data: result };
  } catch (error) {
    return { error: createGlpiErrorMessage(error, "projetos") };
  }
}

export type TicketStatusCount = {
    status: string;
    count: number;
    fill: string;
    textColor?: string;
    order: number;
  };
  
const statusConfig: { [key: number]: { name: string; fill: string, textColor?: string, order: number } } = {
    1: { name: 'Novo', fill: 'hsl(var(--chart-1))', order: 1 },
    2: { name: 'Em Atendimento', fill: 'hsl(var(--chart-2))', order: 2 },
    3: { name: 'Em Atendimento (Planejado)', fill: 'hsl(var(--chart-3))', order: 3 },
    4: { name: 'Pendente', fill: 'hsl(var(--chart-6))', order: 4 },
    5: { name: 'Solucionado', fill: 'hsl(var(--chart-4))', textColor: 'hsl(var(--primary-foreground))', order: 5 },
    6: { name: 'Fechado', fill: 'hsl(var(--chart-5))', textColor: 'hsl(var(--primary-foreground))', order: 6 },
};
  
export async function getTicketsByStatus(): Promise<{ data?: TicketStatusCount[], error?: string }> {
  try {
      const allTickets = await glpiApiRequest<any[]>('/Ticket', {
          is_deleted: '0',
          'criteria[0][field]': 'status',
          'criteria[0][searchtype]': 'less',
          'criteria[0][value]': '5', // Status: Novo, Em atendimento, Em atendimento (planejado), Pendente
          'criteria[1][link]': 'AND',
          'criteria[1][field]': 'entities_id',
          'criteria[1][searchtype]': 'equals',
          'criteria[1][value]': '3', // Apenas da Entidade TI
          range: '0-9999',
      });
    
      // Contagem de chamados por status
      const statusCounts: { [key: number]: number } = {};
      for (const ticket of allTickets) {
          const statusId = ticket.status;
          if (statusConfig[statusId]) {
              statusCounts[statusId] = (statusCounts[statusId] || 0) + 1;
          }
      }

      const result: TicketStatusCount[] = [];
      Object.entries(statusCounts).forEach(([statusId, count]) => {
          const id = parseInt(statusId);
          const config = statusConfig[id];
          if (config) {
              result.push({
                  status: config.name,
                  count: count,
                  fill: config.fill,
                  textColor: config.textColor,
                  order: config.order,
              });
          }
      });
      
      result.sort((a, b) => a.order - b.order);

      return { data: result };

  } catch (error) {
      return { error: createGlpiErrorMessage(error, "tickets por status") };
  }
}

export type SlaData = {
  value: number;
  ticketCount: number;
};

// Mapeamento de prioridade para tempo de SLA em SEGUNDOS
const slaSecondsByPriority: { [key: number]: number } = {
  6: 4 * 3600,  // Crítico: 4 horas
  5: 8 * 3600,  // Muito Alta: 8 horas
  4: 24 * 3600, // Alta: 24 horas
  3: 48 * 3600, // Média: 48 horas
  2: 72 * 3600, // Baixa: 72 horas
  1: 96 * 3600, // Muito Baixa: 96 horas
};

export async function getSlaDataFromGlpi(): Promise<{ data?: SlaData, error?: string }> {
    try {
        const now = new Date();
        const year = getYear(now);
        // Fixa a busca para o mês de Dezembro (índice 11)
        const decemberDate = setMonth(now, 11);

        const firstDayOfMonth = format(startOfMonth(decemberDate), 'yyyy-MM-dd 00:00:00');
        const lastDayOfMonth = format(endOfMonth(decemberDate), 'yyyy-MM-dd 23:59:59');

        const openedTickets = await glpiApiRequest<any[]>('/Ticket', {
            is_deleted: '0',
            'criteria[0][field]': 'date', // Data de abertura do chamado
            'criteria[0][searchtype]': 'between',
            'criteria[0][value]': `${firstDayOfMonth};${lastDayOfMonth}`,
            'criteria[1][link]': 'AND',
            'criteria[1][field]': 'entities_id',
            'criteria[1][searchtype]': 'equals',
            'criteria[1][value]': '3', // Entidade TI
            'criteria[2][link]': 'AND',
            'criteria[2][field]': 'status',
            'criteria[2][searchtype]': 'equals',
            'criteria[2][value]': '5', // Apenas chamados Solucionados
            range: '0-9999',
        });
        
        if (openedTickets.length === 0) {
            return { data: { value: 100, ticketCount: 0 } };
        }

        let ticketsWithinSla = 0;
        for (const ticket of openedTickets) {
            const priority = ticket.priority;
            const timeToResolve = ticket.actiontime; // Tempo de solução em segundos

            if (priority && timeToResolve !== null) {
                const slaTargetSeconds = slaSecondsByPriority[priority];
                if (slaTargetSeconds !== undefined && timeToResolve <= slaTargetSeconds) {
                    ticketsWithinSla++;
                }
            }
        }
        
        const slaPercentage = (ticketsWithinSla / openedTickets.length) * 100;
        
        return {
            data: {
                value: Math.round(slaPercentage),
                ticketCount: openedTickets.length
            }
        };

    } catch (error) {
        return { error: createGlpiErrorMessage(error, "dados de SLA") };
    }
}
