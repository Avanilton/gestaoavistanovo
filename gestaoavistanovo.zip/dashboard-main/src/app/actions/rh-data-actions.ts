
'use server';

import { sankhyaApiRequest } from "./sankhya-actions";
import { getMonth, parse, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// --- Tipos e Constantes ---
const teamMap: { [key: string]: string } = {
    '1': 'ADM',
    '2': 'EXTERNO',
    '3': 'INTERNO',
    '4': 'FINANCEIRO',
    '5': 'LOGÍSTICA',
    '6': 'MARKETING',
    '7': 'TÉCNICA',
    '8': 'TI',
};

export type GestaoAtivaItem = {
    department: string;
    q1: 'SIM' | 'NÃO' | 'NEUTRO';
    q2: 'SIM' | 'NÃO' | 'NEUTRO';
    q3: 'SIM' | 'NÃO' | 'NEUTRO';
    q4: 'SIM' | 'NÃO' | 'NEUTRO';
};

// --- Funções Auxiliares ---
const extractValue = (field: any): string => {
    if (field && typeof field === 'object' && '$' in field) {
        return field['$'];
    }
    if (field !== null && field !== undefined) {
        return String(field);
    }
    return '0';
};

const toNumber = (value: string): number => {
    if (!value) return 0;
    const parsed = parseFloat(value.replace(',', '.'));
    return isNaN(parsed) ? 0 : parsed;
};

const parseSankhyaDate = (dateString: string): Date => {
    let date = parse(dateString, 'dd/MM/yyyy HH:mm:ss', new Date());
    if (isNaN(date.getTime())) {
        date = parse(dateString, 'dd/MM/yyyy', new Date());
    }
    return date;
};

function getQuarter(date: Date): number {
    const month = getMonth(date); // 0-11
    if (month < 3) return 1; // Jan-Mar
    if (month < 6) return 2; // Abr-Jun
    if (month < 9) return 3; // Jul-Set
    return 4; // Out-Dez
}

// --- Funções de Busca de Dados ---

// Busca e ordena todos os dados de RH do Sankhya
async function getRawRhDataFromSankhya(): Promise<{ data?: any[], error?: string }> {
    try {
        const response = await sankhyaApiRequest("VW_LANCAMENTOSRH", [
            "TXRETENCAO", "NPS", "EQUIPE", "PERCENTUAL", "PERIODO", "OPCAO", "SLARECRUTAMENTO"
        ]);

        if (response.error) {
            throw new Error(typeof response.error === 'string' ? response.error : JSON.stringify(response.error));
        }
        
        let rawRecords = response.data?.record;

        if (!rawRecords) {
            return { data: [], error: "Nenhum registro encontrado em VW_LANCAMENTOSRH." };
        }
        
        const records = Array.isArray(rawRecords) ? rawRecords : [rawRecords];

        // Ordena os registros pela data mais recente de forma robusta
        records.sort((a, b) => {
            const dateA = parseSankhyaDate(extractValue(a.PERIODO));
            const dateB = parseSankhyaDate(extractValue(b.PERIODO));

            // Trata datas inválidas para não quebrar a ordenação
            const timeA = !isNaN(dateA.getTime()) ? dateA.getTime() : 0;
            const timeB = !isNaN(dateB.getTime()) ? dateB.getTime() : 0;

            return timeB - timeA;
        });

        return { data: records };
    } catch (error: any) {
        console.error("Erro ao buscar dados de RH do Sankhya:", error);
        return { error: error.message };
    }
}


// Retorna apenas o registro mais recente e o mês de referência
export async function getLatestRhData(): Promise<{ latestRecord?: any; referenceMonth?: string; allRecords?: any[]; error?: string }> {
    const { data: records, error } = await getRawRhDataFromSankhya();
    if (error || !records || records.length === 0) {
        return { error: error || "Dados de RH não encontrados." };
    }
    
    const latestRecord = records[0];
    const referenceMonth = "Tempo Real";

    return { latestRecord, referenceMonth, allRecords: records };
}

// --- Funções Específicas para cada Card ---

export async function getRetentionData(): Promise<{ data?: { value: number }, referenceMonth?: string, error?: string }> {
    const { latestRecord, referenceMonth, error } = await getLatestRhData();
    if (error) return { error };
    
    const retentionValue = toNumber(extractValue(latestRecord.TXRETENCAO));
    return { data: { value: retentionValue }, referenceMonth };
}

export async function getInternalNpsData(): Promise<{ data?: { score: number }, referenceMonth?: string, error?: string }> {
    const { latestRecord, referenceMonth, error } = await getLatestRhData();
    if (error) return { error };
    
    const npsScore = toNumber(extractValue(latestRecord.NPS));
    return { data: { score: npsScore }, referenceMonth };
}

export async function getSlaRecrutamentoData(): Promise<{ data?: { value: number }, referenceMonth?: string, error?: string }> {
    const { latestRecord, referenceMonth, error } = await getLatestRhData();
    if (error) return { error };
    
    const slaValue = toNumber(extractValue(latestRecord.SLARECRUTAMENTO));
    return { data: { value: slaValue }, referenceMonth };
}

export async function getAbsenteeismData(): Promise<{ data?: { byDepartment: { name: string; value: number }[] }, referenceMonth?: string, error?: string }> {
    const { latestRecord, referenceMonth, allRecords: records, error } = await getLatestRhData();
    if (error || !records) {
        return { error: error || "Dados de RH não encontrados." };
    }

    const latestPeriodo = extractValue(latestRecord.PERIODO);
    const latestDate = parseSankhyaDate(latestPeriodo);

    // Filtra registros que são do mesmo mês e ano do mais recente
    const filteredRecords = records.filter(record => {
        const recordDate = parseSankhyaDate(extractValue(record.PERIODO));
        return recordDate.getMonth() === latestDate.getMonth() && recordDate.getFullYear() === latestDate.getFullYear();
    });
    
    const absenteeismByDept = filteredRecords
      .map(record => {
        const teamId = extractValue(record.EQUIPE);
        const teamName = teamMap[teamId] || `Equipe ${teamId}`;
        const percentage = toNumber(extractValue(record.PERCENTUAL));
        return { name: teamName, value: percentage };
      })
      .filter(item => item.value > 0); 
    
    // Garante que cada equipe apareça apenas uma vez
    const uniqueData = Array.from(new Map(absenteeismByDept.map(item => [item.name, item])).values());

    return { data: { byDepartment: uniqueData }, referenceMonth };
}

export async function getGestaoAtivaData(): Promise<{ data?: GestaoAtivaItem[], referenceMonth?: string, error?: string }> {
    const { allRecords: records, referenceMonth, error } = await getLatestRhData();
    if (error || !records) {
        return { error: error || "Dados de RH não encontrados." };
    }

    const processedData: { [key: string]: { q1: 'SIM' | 'NÃO' | 'NEUTRO', q2: 'SIM' | 'NÃO' | 'NEUTRO', q3: 'SIM' | 'NÃO' | 'NEUTRO', q4: 'SIM' | 'NÃO' | 'NEUTRO' } } = {};
    
    Object.values(teamMap).forEach(teamName => {
        processedData[teamName] = { q1: 'NEUTRO', q2: 'NEUTRO', q3: 'NEUTRO', q4: 'NEUTRO' };
    });

    records.forEach(record => {
        const teamId = extractValue(record.EQUIPE);
        const teamName = teamMap[teamId];
        const periodoStr = extractValue(record.PERIODO);
        const opcao = extractValue(record.OPCAO);

        if (teamName && periodoStr && (opcao === '1' || opcao === '2')) {
            try {
                const recordDate = parseSankhyaDate(periodoStr);
                if (!isNaN(recordDate.getTime())) {
                    const quarter = getQuarter(recordDate);
                    const result = opcao === '1' ? 'SIM' : 'NÃO';
                    
                    if (quarter === 1) processedData[teamName].q1 = result;
                    else if (quarter === 2) processedData[teamName].q2 = result;
                    else if (quarter === 3) processedData[teamName].q3 = result;
                    else if (quarter === 4) processedData[teamName].q4 = result;
                }
            } catch (e) {
                // Ignora erros de parse de datas inválidas
            }
        }
    });

    const finalData: GestaoAtivaItem[] = Object.entries(processedData).map(([department, quarters]) => ({
        department,
        ...quarters
    }));

    return { data: finalData, referenceMonth };
}
