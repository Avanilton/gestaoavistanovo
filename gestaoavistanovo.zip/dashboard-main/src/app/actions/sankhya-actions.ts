
'use server';

import { URLSearchParams } from "url";

async function getSankhyaAuthToken(): Promise<string> {
    const authUrl = process.env.SANKHYA_API_URL;
    const clientId = process.env.SANKHYA_CLIENT_ID;
    const clientSecret = process.env.SANKHYA_CLIENT_SECRET;
    const xToken = process.env.SANKHYA_X_TOKEN;


    if (!authUrl || !clientId || !clientSecret || !xToken) {
        const missing = [
            !authUrl && "SANKHYA_API_URL",
            !clientId && "SANKHYA_CLIENT_ID",
            !clientSecret && "SANKHYA_CLIENT_SECRET",
            !xToken && "SANKHYA_X_TOKEN",
        ].filter(Boolean).join(', ');
        throw new Error(`Variáveis de ambiente da API Sankhya não configuradas: ${missing}.`);
    }
    
    const params = new URLSearchParams();
    params.append('grant_type', 'client_credentials');
    params.append('client_id', clientId);
    params.append('client_secret', clientSecret);
    
    try {
        const response = await fetch(authUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Token': xToken,
            },
            body: params.toString(),
            cache: 'no-store',
        });
        
        const responseBody = await response.json();

        if (!response.ok) {
            const errorMessage = responseBody.error_description || responseBody.error || responseBody.message || responseBody;
            const detailedError = typeof errorMessage === 'string' ? errorMessage : JSON.stringify(errorMessage);
            throw new Error(`Falha na autenticação Sankhya: ${detailedError}`);
        }
        
        if (responseBody.access_token) {
            return responseBody.access_token;
        } else {
            throw new Error('Token de acesso não encontrado na resposta de autenticação Sankhya.');
        }

    } catch (error: any) {
        throw new Error(`Ocorreu um erro de rede durante a autenticação com Sankhya: ${error.message}`);
    }
}

// Função genérica para fazer requisições para a API Sankhya
export async function sankhyaApiRequest(viewName: string, fields: string[], criteria?: any): Promise<{ data?: any; error?: any; raw?: any }> {
    try {
        const token = await getSankhyaAuthToken();
        const serviceUrl = "https://api.sankhya.com.br/gateway/v1/mge/service.sbr?serviceName=CRUDServiceProvider.loadView&outputType=json";

        const query: any = {
            viewName: viewName,
            fields: {
                field: fields.map(f => ({ "$": f }))
            }
        };

        if (criteria) {
            query.criteria = criteria;
        }

        const body = {
            serviceName: "CRUDServiceProvider.loadView",
            requestBody: {
                query: query
            }
        };

        const response = await fetch(serviceUrl, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(body),
            cache: 'no-store' // Busca em tempo real, sem cache
        });

        const json = await response.json();
        
        if (json.status !== "1" || !response.ok) {
            const statusMessage = json?.statusMessage || "Mensagem de erro não disponível.";
            throw new Error(`A API Sankhya retornou um erro: ${statusMessage}`);
        }
        
        const records = json?.responseBody?.records?.record;
        if (!records) {
            return { data: { record: [] }, raw: json };
        }

        return { data: { record: Array.isArray(records) ? records : [records] }, raw: json };

    } catch (error: any) {
        return { error: error.message || "Ocorreu um erro desconhecido na API Sankhya." };
    }
}


export type SankhyaTeamData = {
    CODEQUIPE: string;
    PERCENTUAL: number;
    DM: number;
    PMF: number;
    MIX: number;
    CLIENTES_ATENDIDOS: number;
};

const extractValue = (field: any): string => {
    if (field && typeof field === 'object' && '$' in field) {
        return field['$'];
    }
    if (field !== null && field !== undefined) {
        return String(field);
    }
    return '0';
};

const toNumber = (value: string | number): number => {
    if (typeof value !== 'string') {
        value = String(value);
    }
    if (!value) return 0;
    const parsed = parseFloat(value.replace(',', '.'));
    return isNaN(parsed) ? 0 : parsed;
};


export async function getComercialData(): Promise<{ data?: SankhyaTeamData[]; error?: any; raw?: any }> {
    const { data: rawData, error, raw } = await sankhyaApiRequest("VW_DESEMPENHO_EQUIPE", ["CODEQUIPE", "PERCENTUAL", "DM", "PMF", "MIX", "CLIENTES_ATENDIDOS"]);

    if (error) {
        return { error, raw };
    }

    if (!rawData || !rawData.record) {
        return { data: [], raw };
    }
    
    const data: SankhyaTeamData[] = rawData.record.map((record: any) => ({
        CODEQUIPE: extractValue(record.CODEQUIPE),
        PERCENTUAL: toNumber(extractValue(record.PERCENTUAL)),
        DM: toNumber(extractValue(record.DM)),
        PMF: toNumber(extractValue(record.PMF)),
        MIX: toNumber(extractValue(record.MIX)),
        CLIENTES_ATENDIDOS: toNumber(extractValue(record.CLIENTES_ATENDIDOS)),
    }));
    
    return { data, raw };
}

export type ComercialResumoGeralData = {
    equipe: string;
    percentual: number;
    dm: number;
    pmf: number;
    descmes: string;
};

export async function getComercialResumoGeralData(): Promise<{ data?: ComercialResumoGeralData[]; error?: any; raw?: any }> {
    const { data: rawData, error, raw } = await sankhyaApiRequest("DC_PT_MONITOR_RESUMO_GERAL", ["PERCENTUAL", "DM", "PMF", "CODEQUIPES", "DESCMES"]);

    if (error) {
        return { error, raw };
    }

    if (!rawData || !rawData.record) {
        return { data: [], raw };
    }
    
    const data: ComercialResumoGeralData[] = rawData.record.map((record: any) => ({
        equipe: extractValue(record.CODEQUIPES),
        percentual: toNumber(extractValue(record.PERCENTUAL)),
        dm: toNumber(extractValue(record.DM)),
        pmf: toNumber(extractValue(record.PMF)),
        descmes: extractValue(record.DESCMES),
    }));
    
    return { data, raw };
}


export type EmbarqueChinaData = {
    nunota: string | null;
    ad_dt_embarque: string | null;
    dtprevent: string | null;
    dtentsai: string | null;
    identificacao: string | null;
};


export async function getEmbarqueChinaData(): Promise<{ data?: EmbarqueChinaData[]; error?: any; raw?: any }> {
    const { data: rawData, error, raw } = await sankhyaApiRequest("EMBARQUECHINA", ["DTPREVENT", "DTENTSAI", "IDENTIFICACAO"]);

     if (error) {
        return { error, raw };
    }

    if (!rawData || !rawData.record) {
        return { data: [], raw };
    }

    const data: EmbarqueChinaData[] = rawData.record.map((record: any) => ({
        nunota: null, // Campo removido da consulta
        ad_dt_embarque: null, // Campo removido da consulta
        dtprevent: extractValue(record.DTPREVENT) || null,
        dtentsai: extractValue(record.DTENTSAI) || null,
        identificacao: extractValue(record.IDENTIFICACAO) || null,
    }));

    return { data, raw };
}


export type SankhyaMarketingData = {
    periodo: string;
    tkMedio: number;
    cac: number;
    txConversao: number;
    atividades: number;
};

export async function getMarketingData(): Promise<{ data?: SankhyaMarketingData; error?: any; raw?: any }> {
    const { data: rawData, error, raw } = await sankhyaApiRequest("VW_MARKETING", ["PERIODO", "TKMEDIO", "CAC", "TXCONVERSAO", "ATIVIDADES"]);

    if (error) {
        return { error, raw };
    }

    let records = rawData?.record;
    if (!records || (Array.isArray(records) && records.length === 0)) {
        return { error: "Nenhum dado de marketing foi retornado pela API.", raw };
    }

    if (!Array.isArray(records)) {
        records = [records];
    }
    
    records.sort((a: any, b: any) => {
        const dateA = new Date(extractValue(a.PERIODO).split('/').reverse().join('-'));
        const dateB = new Date(extractValue(b.PERIODO).split('/').reverse().join('-'));
        return dateB.getTime() - dateA.getTime();
    });

    const latestRecord = records[0];

    const data: SankhyaMarketingData = {
        periodo: extractValue(latestRecord.PERIODO),
        tkMedio: toNumber(extractValue(latestRecord.TKMEDIO)),
        cac: toNumber(extractValue(latestRecord.CAC)),
        txConversao: toNumber(extractValue(latestRecord.TXCONVERSAO)),
        atividades: toNumber(extractValue(latestRecord.ATIVIDADES)),
    };

    return { data, raw };
}

export type CicloPedidoSankhyaData = {
    tempoMedioEmMinutos: number;
    totalPedidos: number;
};

export async function getCicloPedidoSankhya(): Promise<{ data?: CicloPedidoSankhyaData; error?: any; raw?: any }> {
    const { data: rawData, error, raw } = await sankhyaApiRequest("VW_CICLOPEDIDO", ["TOTAL_MINUTOS"]);

    if (error) {
        return { error, raw };
    }

    if (!rawData || !rawData.record || rawData.record.length === 0) {
        return { data: { tempoMedioEmMinutos: 0, totalPedidos: 0 }, raw };
    }

    const numericValues = rawData.record.map((record: any) => {
        const minutesString = extractValue(record.TOTAL_MINUTOS);
        return toNumber(minutesString);
    }).filter((value: number) => !isNaN(value));


    const totalPedidos = numericValues.length;
    if (totalPedidos === 0) {
        return { data: { tempoMedioEmMinutos: 0, totalPedidos: 0 }, raw };
    }
    
    const sumOfMinutes = numericValues.reduce((acc: number, value: number) => acc + value, 0);
    
    const averageInMinutes = Math.round(sumOfMinutes / totalPedidos);

    const data: CicloPedidoSankhyaData = {
        tempoMedioEmMinutos: averageInMinutes,
        totalPedidos: totalPedidos,
    };
    
    return { data, raw };
}


export type AprovacoesData = {
    total: number;
    aprovados: number;
    reprovados: number;
    percentualAprovados: number;
    percentualReprovados: number;
};

export async function getAprovacoesData(): Promise<{ data?: AprovacoesData; error?: any }> {
    const { data: rawData, error } = await sankhyaApiRequest("VW_APROVACOES", ["SITUACAOVALOR"]);

    if (error) {
        return { error };
    }

    if (!rawData || !rawData.record) {
        return { data: { total: 0, aprovados: 0, reprovados: 0, percentualAprovados: 0, percentualReprovados: 0 } };
    }
    
    const records = rawData.record;
    const total = records.length;

    let aprovados = 0;
    let reprovados = 0;

    records.forEach((record: any) => {
        const situacao = extractValue(record.SITUACAOVALOR);
        if (situacao === '1' || situacao === '1,00') {
            aprovados++;
        } else if (situacao === '0' || situacao === '0,00') {
            reprovados++;
        }
    });

    const percentualAprovados = total > 0 ? (aprovados / total) * 100 : 0;
    const percentualReprovados = total > 0 ? (reprovados / total) * 100 : 0;

    return {
        data: {
            total,
            aprovados,
            reprovados,
            percentualAprovados,
            percentualReprovados,
        }
    };
}
