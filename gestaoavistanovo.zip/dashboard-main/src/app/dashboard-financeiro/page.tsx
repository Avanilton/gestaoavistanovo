import { Header } from "@/components/dashboard/header";
import { AutoRefresher } from "@/components/dashboard/auto-refresher";
import { InadimplenciaCard } from "@/components/dashboard-financeiro/inadimplencia-card";
import { DataSourceLabel } from "@/components/dashboard/data-source-label";
import { AutoPageSwitcher } from "@/components/dashboard/auto-page-switcher";
import { AprovacoesCard } from "@/components/dashboard-financeiro/aprovacoes-card";

export const dynamic = 'force-dynamic';

export default function DashboardFinanceiroPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <AutoPageSwitcher />
      <AutoRefresher />
      <Header />
      <main className="flex flex-1 flex-col gap-8 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-end">
          <DataSourceLabel source="Planilha & Sankhya" />
        </div>
        <InadimplenciaCard />
        <AprovacoesCard />
      </main>
    </div>
  );
}
