
import type { Metadata } from "next";
import "./globals.css";
import { cn } from "@/lib/utils";
import { PageSwitcherProvider } from "@/contexts/page-switcher-context";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Gestão à Vista",
  description: "Dashboard de indicadores da empresa.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn("min-h-screen bg-background font-sans antialiased")}>
        <PageSwitcherProvider>
          {children}
          <Toaster />
        </PageSwitcherProvider>
      </body>
    </html>
  );
}
