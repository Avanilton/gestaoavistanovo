"use client";

export function useMobile() {
  return { isMobile: false };
}
