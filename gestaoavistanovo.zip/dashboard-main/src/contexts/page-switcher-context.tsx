
"use client";

import { createContext, useState, useContext, ReactNode, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';

type PageSwitcherContextType = {
  isPaused: boolean;
  togglePause: () => void;
  setCurrentPage: (path: string) => void;
};

const PageSwitcherContext = createContext<PageSwitcherContextType | undefined>(undefined);

// Lista de dashboards ativos na rotação
const pages = [
  { path: "/dashboard-ti", duration: 40000, scrollDelay: 15000 },
  { path: "/dashboard-logistica", duration: 20000, scrollDelay: 10000 },
  { path: "/dashboard-rh", duration: 25000, scrollDelay: 12000 },
  { path: "/dashboard-pos-vendas", duration: 25000, scrollDelay: 12000 },
  { path: "/dashboard-mkt", duration: 20000, scrollDelay: 10000 },
  { path: "/dashboard-comercial", duration: 30000, scrollDelay: 15000 },
  { path: "/dashboard-financeiro", duration: 25000, scrollDelay: 12000 },
  { path: "/dashboard-tecnica", duration: 40000, scrollDelay: 15000 },
  { path: "/dashboard-comex", duration: 20000, scrollDelay: 10000 },
  { path: "/dashboard-liga-decorlux", duration: 20000, scrollDelay: 10000 },
  // Diversos agora tem 12 fotos com 20s cada. Total 240s (4 minutos).
  { path: "/dashboard-diversos", duration: 240000, scrollDelay: 10000 },
];

export function PageSwitcherProvider({ children }: { children: ReactNode }) {
  const [isPaused, setIsPaused] = useState(false);
  const [currentPagePath, setCurrentPagePath] = useState<string>('');
  
  const router = useRouter();
  const pageTimerRef = useRef<NodeJS.Timeout | null>(null);
  const scrollTimerRef = useRef<NodeJS.Timeout | null>(null);

  const clearAllTimeouts = useCallback(() => {
    if (pageTimerRef.current) {
      clearTimeout(pageTimerRef.current);
      pageTimerRef.current = null;
    }
    if (scrollTimerRef.current) {
      clearTimeout(scrollTimerRef.current);
      scrollTimerRef.current = null;
    }
  }, []);

  const scheduleNextPage = useCallback((path: string) => {
    const currentIndex = pages.findIndex(p => p.path === path);
    if (currentIndex === -1) return;

    const currentPageConfig = pages[currentIndex];
    const nextIndex = (currentIndex + 1) % pages.length;
    const nextPath = pages[nextIndex].path;
    
    pageTimerRef.current = setTimeout(() => {
        router.push(nextPath);
    }, currentPageConfig.duration);
  }, [router]);
  
  const scheduleScroll = useCallback((path: string) => {
      const pageConfig = pages.find(p => p.path === path);
      const scrollDelay = pageConfig ? pageConfig.scrollDelay : 10000;

      scrollTimerRef.current = setTimeout(() => {
          if (typeof window !== 'undefined' && document.documentElement.scrollHeight > document.documentElement.clientHeight) {
            window.scrollTo({
              top: document.documentElement.scrollHeight,
              behavior: 'smooth'
            });
          }
      }, scrollDelay);
  }, []);

  useEffect(() => {
    clearAllTimeouts();

    if (!isPaused && currentPagePath) {
      scheduleScroll(currentPagePath);
      scheduleNextPage(currentPagePath);
    }

    return () => {
      clearAllTimeouts();
    };
  }, [currentPagePath, isPaused, clearAllTimeouts, scheduleScroll, scheduleNextPage]);

  const togglePause = () => {
    setIsPaused(prev => !prev);
  };
  
  const setCurrentPage = (path: string) => {
      setCurrentPagePath(path);
  }

  const value = {
    isPaused,
    togglePause,
    setCurrentPage,
  };

  return (
    <PageSwitcherContext.Provider value={value}>
      {children}
      <style jsx global>{`
        ::-webkit-scrollbar {
          width: 0px;
          background: transparent;
        }
        body {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
      `}</style>
    </PageSwitcherContext.Provider>
  );
}

export function usePageSwitcher() {
  const context = useContext(PageSwitcherContext);
  if (context === undefined) {
    throw new Error('usePageSwitcher must be used within a PageSwitcherProvider');
  }
  return context;
}
