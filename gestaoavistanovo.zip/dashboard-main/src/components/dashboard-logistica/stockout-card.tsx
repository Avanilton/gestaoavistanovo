
"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { PackageX } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type StockoutCardProps = {
  className?: string;
};

export function StockoutCard({ className }: StockoutCardProps) {
  const [data] = useState({ value: 2.56 });
  const [isLoading] = useState(false);
  const [updateTimestamp] = useState<number>(Date.now());


  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center">
          <Skeleton className="h-16 w-36" />
        </div>
      );
    }
    
    const color = "text-destructive";

    return (
      <div className={cn("text-7xl font-bold flex items-center", color)}>
        {data.value.toFixed(2).replace('.',',')}%
      </div>
    );
  };

  return (
    <Card className={cn("flex flex-col", className)}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <PackageX className="h-5 w-5 text-primary" />
          <CardTitle className="text-xl font-semibold">Ruptura (Stockout)</CardTitle>
        </div>
        <CardDescription>Ruptura de estoque sobre o orçamento</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col items-center justify-center">
        {renderContent()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth="Fevereiro" />
        </CardFooter>
      )}
    </Card>
  );
}
