"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { getCicloPedidoSankhya, type CicloPedidoSankhyaData } from "@/app/actions/sankhya-actions";
import { cn } from "@/lib/utils";
import { Timer, AlertTriangle, PackageSearch } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type CicloPedidoCardProps = {
    className?: string;
};

export function CicloPedidoCard({ className }: CicloPedidoCardProps) {
    const [data, setData] = useState<CicloPedidoSankhyaData | undefined>(undefined);
    const [error, setError] = useState<string | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(true);
    const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());

    useEffect(() => {
        async function fetchData() {
            try {
                setIsLoading(true);
                const result = await getCicloPedidoSankhya();
                if (result.error) {
                    setError(typeof result.error === 'string' ? result.error : JSON.stringify(result.error));
                } else {
                    setData(result.data);
                }
            } catch (e: any) {
                setError(e.message || "Ocorreu um erro desconhecido.");
            } finally {
                setIsLoading(false);
                setUpdateTimestamp(Date.now());
            }
        }
        fetchData();
    }, []);

    const formatTime = (minutes: number) => {
        if (minutes < 60) {
            return `${minutes} min`;
        }
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        
        if (remainingMinutes === 0) {
            return `${hours}h`;
        }
        
        return `${hours}h ${remainingMinutes}min`;
    };

    const renderContent = () => {
        if (isLoading) {
            return (
                 <div className="flex flex-col items-center justify-center">
                    <Skeleton className="h-16 w-32" />
                    <Skeleton className="h-4 w-40 mt-4" />
                 </div>
            );
        }

        if (error) {
            return (
                <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[120px]">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <p className="font-semibold">Falha ao carregar dados</p>
                    <p className="text-xs">{error}</p>
                </div>
            );
        }
        
        if (!data || data.totalPedidos === 0) {
            return (
                <div className="flex flex-col items-center justify-center text-center text-muted-foreground h-full min-h-[120px]">
                     <PackageSearch className="h-6 w-6 mb-2" />
                     <p>Nenhum pedido encontrado para análise.</p>
                </div>
            );
        }
        
        return (
            <div className="text-center">
                <div className="text-6xl font-bold">
                    {formatTime(data.tempoMedioEmMinutos)}
                </div>
                 <p className="text-sm text-muted-foreground mt-2">
                    Baseado em {data.totalPedidos} pedidos analisados.
                </p>
            </div>
        );
    }

  return (
    <Card className={cn("flex flex-col", className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Timer className="h-5 w-5 text-primary" />
          Ciclo do Pedido
        </CardTitle>
        <CardDescription>Tempo médio da Fatura até a Liberação</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center justify-center">
        {renderContent()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
          <CardUpdateFooter updateTimestamp={updateTimestamp} />
        </CardFooter>
      )}
    </Card>
  );
}
