
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Ship, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { CardUpdateFooter } from "../dashboard/card-update-footer";
import { Badge } from "@/components/ui/badge";
import { getEmbarqueChinaData, type EmbarqueChinaData } from "@/app/actions/sankhya-actions";
import { Skeleton } from "@/components/ui/skeleton";
import { getMonth, getYear, parse, differenceInDays, isValid } from "date-fns";

type MappedEmbarqueData = {
    id: string | null;
    processo: string | null;
    dataPedido: string | null;
    dataPrevista: string | null;
    tempo: number | null;
}

// Função para parse de datas que podem estar em formatos diferentes
function parseFlexibleDate(dateString: string): Date | null {
    if (!dateString) return null;

    // Tenta formato 'dd/MM/yyyy HH:mm:ss'
    let date = parse(dateString, 'dd/MM/yyyy HH:mm:ss', new Date());
    if (isValid(date)) return date;
    
    // Tenta formato 'dd/MM/yyyy'
    date = parse(dateString, 'dd/MM/yyyy', new Date());
    if (isValid(date)) return date;

    // Tenta o parse nativo do JS, que cobre ISO 8601 e outros formatos
    date = new Date(dateString);
    if (isValid(date)) return date;

    return null;
}


export function EmbarqueCard({ className }: { className?: string }) {
  const [data, setData] = useState<MappedEmbarqueData[] | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState(Date.now());

  useEffect(() => {
    async function fetchData() {
        try {
            setIsLoading(true);
            const result = await getEmbarqueChinaData();
            
            if (result.error) {
                setError(result.error);
            } else if (result.data) {
                const now = new Date();
                const currentMonth = getMonth(now);
                const currentYear = getYear(now);

                const filteredAndMappedData = result.data
                    .map(item => {
                        const dtprevent = item.dtprevent ? parseFlexibleDate(item.dtprevent) : null;
                        const dtentsai = item.dtentsai ? parseFlexibleDate(item.dtentsai) : null;

                        return { ...item, dtprevent, dtentsai };
                    })
                    .filter(item => {
                        return item.dtprevent &&
                               getMonth(item.dtprevent) === currentMonth &&
                               getYear(item.dtprevent) === currentYear;
                    })
                    .map(item => {
                        let tempo: number | null = null;
                        if (item.dtprevent && item.dtentsai) {
                            tempo = differenceInDays(item.dtprevent, item.dtentsai);
                        }

                        return {
                            id: item.identificacao,
                            processo: item.identificacao,
                            dataPedido: item.dtentsai?.toLocaleDateString('pt-BR') || null,
                            dataPrevista: item.dtprevent?.toLocaleDateString('pt-BR') || null,
                            tempo: tempo,
                        }
                    });
                setData(filteredAndMappedData);
            }
        } catch (e: any) {
            setError(e.message || "Ocorreu um erro desconhecido.");
        } finally {
            setIsLoading(false);
            setUpdateTimestamp(Date.now());
        }
    }
    fetchData();
  }, []);

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A";
    return dateString;
  }

  const renderContent = () => {
    if (isLoading) {
        return (
             <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Processo</TableHead>
                        <TableHead>Data do Pedido</TableHead>
                        <TableHead>Prev. Chegada</TableHead>
                        <TableHead>Status (Até dia 05)</TableHead>
                        <TableHead className="text-right">Tempo (dias)</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                   {[...Array(3)].map((_, i) => (
                     <TableRow key={i}>
                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                        <TableCell className="text-right"><Skeleton className="h-5 w-12 ml-auto" /></TableCell>
                     </TableRow>
                   ))}
                </TableBody>
             </Table>
        );
    }
    
    if (error) {
        return (
            <div className="flex flex-col items-center justify-center h-full min-h-[150px] text-destructive">
                <AlertTriangle className="h-6 w-6 mb-2" />
                <p className="font-semibold">Falha ao carregar dados</p>
                <p className="text-xs text-center">{typeof error === 'string' ? error : JSON.stringify(error)}</p>
            </div>
        );
    }

    if (!data || data.length === 0) {
        return (
            <div className="flex h-full min-h-[150px] items-center justify-center text-muted-foreground">
                Nenhum embarque previsto para o mês atual.
            </div>
        );
    }

    return (
        <Table className="text-lg">
            <TableHeader>
                <TableRow>
                    <TableHead className="text-xl">Processo</TableHead>
                    <TableHead className="text-xl">Data do Pedido</TableHead>
                    <TableHead className="text-xl">Prev. Chegada</TableHead>
                    <TableHead className="text-xl">Status (Até dia 05)</TableHead>
                    <TableHead className="text-right text-xl">Tempo (dias)</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {data.map((item) => (
                    <TableRow key={item.id}>
                        <TableCell className="font-medium text-xl">{item.processo || 'N/A'}</TableCell>
                        <TableCell className="text-xl">{formatDate(item.dataPedido)}</TableCell>
                        <TableCell className="text-xl">{formatDate(item.dataPrevista)}</TableCell>
                         <TableCell>
                           <Badge variant={item.tempo !== null ? (item.tempo <= 45 ? "default" : "destructive") : "secondary"}
                                  className={cn(
                                    "text-lg", 
                                    item.tempo !== null && item.tempo <= 45 && "bg-green-500 hover:bg-green-600",
                                  )}>
                                {item.tempo !== null ? (item.tempo <= 45 ? "No Prazo" : "Fora do Prazo") : 'N/A'}
                            </Badge>
                        </TableCell>
                        <TableCell className="text-right font-medium text-xl">
                            {item.tempo !== null ? `${item.tempo}` : '-'}
                        </TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    );
  }

  return (
    <Card className={cn(className, "flex flex-col")}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Ship className="h-5 w-5 text-primary" />
          <CardTitle>Status de Embarques</CardTitle>
        </div>
        <CardDescription>Acompanhamento de embarques com previsão de chegada para o mês atual (Sankhya)</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        {renderContent()}
      </CardContent>
      {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} />
        </CardFooter>
      )}
    </Card>
  );
}
