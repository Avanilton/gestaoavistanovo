
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from '@/components/ui/skeleton';
import { AlertTriangle, TrendingUp, Smile, Frown, Meh } from 'lucide-react';
import { getGestaoAtivaData, type GestaoAtivaItem } from '@/app/actions/rh-data-actions';
import { cn } from '@/lib/utils';
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type GestaoAtivaCardProps = {
    className?: string;
};

export function GestaoAtivaCard({ className }: GestaoAtivaCardProps) {
    const [data, setData] = useState<GestaoAtivaItem[] | undefined>(undefined);
    const [referenceMonth, setReferenceMonth] = useState<string | undefined>();
    const [error, setError] = useState<string | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(true);
    const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());


    useEffect(() => {
        async function fetchData() {
            try {
                setIsLoading(true);
                const result = await getGestaoAtivaData();
                if (result.error) {
                    throw new Error(result.error);
                }
                // Ordenar para garantir consistência
                const sortedData = result.data?.sort((a, b) => a.department.localeCompare(b.department));
                setData(sortedData);
                setReferenceMonth(result.referenceMonth);
            } catch (e: any) {
                setError(e.message || "Ocorreu um erro desconhecido.");
            } finally {
                setIsLoading(false);
                setUpdateTimestamp(Date.now());
            }
        }
        fetchData();
    }, []);
    
    const StatusIcon = ({ status }: { status: 'SIM' | 'NÃO' | 'NEUTRO' }) => {
        if (status === 'SIM') return <Smile className="h-5 w-5 text-green-500 mx-auto" />;
        if (status === 'NÃO') return <Frown className="h-5 w-5 text-red-500 mx-auto" />;
        return <Meh className="h-5 w-5 text-yellow-500 mx-auto" />;
    };


    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                        <div key={i} className="flex items-center justify-between p-2">
                            <Skeleton className="h-5 w-1/4" />
                            <Skeleton className="h-6 w-6 rounded-full" />
                            <Skeleton className="h-6 w-6 rounded-full" />
                            <Skeleton className="h-6 w-6 rounded-full" />
                            <Skeleton className="h-6 w-6 rounded-full" />
                        </div>
                    ))}
                </div>
            );
        }

        if (error) {
            return (
                <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[150px]">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <p className="font-semibold">{error}</p>
                </div>
            );
        }
        
        if (!data || data.length === 0) {
            return (
                <div className="flex h-full min-h-[150px] items-center justify-center text-muted-foreground">
                    Nenhum departamento encontrado para análise.
                </div>
            );
        }

        return (
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Departamento</TableHead>
                        <TableHead className="text-center">1º Trim</TableHead>
                        <TableHead className="text-center">2º Trim</TableHead>
                        <TableHead className="text-center">3º Trim</TableHead>
                        <TableHead className="text-center">4º Trim</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {data.map((item, index) => (
                        <TableRow key={index}>
                            <TableCell className="font-medium">{item.department}</TableCell>
                            <TableCell className="text-center"><StatusIcon status={item.q1} /></TableCell>
                            <TableCell className="text-center"><StatusIcon status={item.q2} /></TableCell>
                            <TableCell className="text-center"><StatusIcon status={item.q3} /></TableCell>
                            <TableCell className="text-center"><StatusIcon status={item.q4} /></TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        );
    };

    return (
        <Card className={cn(className, "flex flex-col")}>
            <CardHeader>
                <div className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <CardTitle>Gestão Ativa</CardTitle>
                </div>
                <CardDescription>Status de engajamento por departamento (trimestral)</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
                {renderContent()}
            </CardContent>
            {!isLoading && (
              <CardFooter className="p-0">
                  <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
              </CardFooter>
            )}
        </Card>
    );
}
