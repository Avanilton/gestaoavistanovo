
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { HeartHandshake, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { ChartContainer, ChartConfig } from "@/components/ui/chart";
import { RadialBar, RadialBarChart, ResponsiveContainer } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { getRetentionData } from "@/app/actions/rh-data-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type RetentionData = {
  value: number;
};

type RetentionCardProps = {
  className?: string;
};

const getRetentionColor = (value: number): { color: string, className: string } => {
    if (value <= 30) return { color: 'hsl(var(--chart-4))', className: 'text-destructive-foreground' };
    if (value <= 59) return { color: 'hsl(var(--chart-6))', className: 'text-foreground' };
    if (value <= 89) return { color: 'hsl(var(--chart-2))', className: 'text-foreground' };
    return { color: 'hsl(var(--chart-1))', className: 'text-foreground' };
};

export function RetentionCard({ className }: RetentionCardProps) {
  const [data, setData] = useState<RetentionData | undefined>(undefined);
  const [referenceMonth, setReferenceMonth] = useState<string | undefined>();
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());


  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getRetentionData();
        if (result.error) {
          throw new Error(result.error);
        }
        setData(result.data);
        setReferenceMonth(result.referenceMonth);
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);
  
  const renderContent = () => {
    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-[200px]">
                <Skeleton className="h-52 w-52 rounded-full" />
            </div>
        );
    }
    
    if (error) {
       return (
        <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[180px]">
            <AlertTriangle className="h-6 w-6 mb-2" />
            <p className="font-semibold">Erro ao carregar</p>
            <p className="text-xs">{error}</p>
        </div>
      );
    }

    if (data === undefined) {
        return <p className="flex items-center justify-center h-[180px] text-muted-foreground">Nenhum dado encontrado.</p>;
    }

    const { color: barColor, className: textColor } = getRetentionColor(data.value);

    const chartConfig: ChartConfig = {
        retention: {
            label: "Retenção",
            color: barColor,
        },
    };
    
    const chartData = [{ name: "retention", value: data.value, fill: "var(--color-retention)" }];

    return (
        <div className="relative mx-auto aspect-square h-full max-h-[250px]">
            <ChartContainer
                config={chartConfig}
                className="mx-auto aspect-square h-full w-full"
            >
                <ResponsiveContainer width="100%" height="100%">
                    <RadialBarChart
                        data={chartData}
                        startAngle={90}
                        endAngle={-270}
                        innerRadius="75%"
                        outerRadius="100%"
                        barSize={24}
                        cy="50%"
                    >
                        <RadialBar
                            dataKey="value"
                            background={{ fill: "hsl(var(--muted))" }}
                            cornerRadius={12}
                            isAnimationActive={true}
                        />
                    </RadialBarChart>
                </ResponsiveContainer>
            </ChartContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={cn("text-5xl font-bold", textColor)} style={{color: barColor}}>{data.value.toFixed(1)}%</span>
            </div>
        </div>
    );
  };

  return (
    <Card className={cn("flex flex-col", className)}>
      <CardHeader>
        <div className="flex items-center gap-2">
            <HeartHandshake className="h-5 w-5 text-primary" />
            <CardTitle>Retenção</CardTitle>
        </div>
        <CardDescription>Taxa de retenção de talentos (anual)</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex items-center justify-center pb-0 min-h-[250px]">
        {renderContent()}
      </CardContent>
      {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
        </CardFooter>
      )}
    </Card>
  );
}
