
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { SmilePlus, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { getInternalNpsData } from "@/app/actions/rh-data-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type InternalNpsData = {
  score: number;
};

type InternalNpsCardProps = {
  className?: string;
};

function getNpsCategory(score: number): { label: string, color: string } {
    if (score >= 75) return { label: 'Excelente', color: 'text-green-500' };
    if (score >= 50) return { label: 'Aperfeiçoamento', color: 'text-yellow-500' };
    if (score >= 0) return { label: 'Crítico', color: 'text-orange-500' };
    return { label: 'Crítico', color: 'text-red-500' };
}

export function InternalNpsCard({ className }: InternalNpsCardProps) {
    const [data, setData] = useState<InternalNpsData | undefined>(undefined);
    const [referenceMonth, setReferenceMonth] = useState<string | undefined>();
    const [error, setError] = useState<string | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(true);
    const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());
    const lastScore = 75; // Valor estático do ciclo anterior

    useEffect(() => {
        async function fetchData() {
            try {
                setIsLoading(true);
                const result = await getInternalNpsData();
                if (result.error) {
                    throw new Error(result.error);
                }
                setData(result.data);
                setReferenceMonth(result.referenceMonth);
            } catch (e: any) {
                setError(e.message || "Ocorreu um erro desconhecido.");
            } finally {
                setIsLoading(false);
                setUpdateTimestamp(Date.now());
            }
        }
        fetchData();
    }, []);
    
    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center min-h-[120px]">
                    <Skeleton className="h-14 w-20 mb-2" />
                    <Skeleton className="h-6 w-28 mb-2" />
                    <Skeleton className="h-4 w-36" />
                </div>
            );
        }

        if (error) {
            return (
                <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[120px]">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <p className="font-semibold">Erro ao carregar</p>
                    <p className="text-xs">{error}</p>
                </div>
            );
        }

        if (data === undefined) {
            return <p className="text-muted-foreground flex items-center justify-center min-h-[120px]">Nenhum dado encontrado.</p>;
        }

        const category = getNpsCategory(data.score);
        const improvement = data.score - lastScore;

        return (
            <div className="flex flex-col items-center justify-center min-h-[120px]">
                <div className="text-6xl font-bold">{data.score}</div>
                <p className={cn("text-lg font-semibold", category.color)}>{category.label}</p>
                <p className="text-xs text-muted-foreground mt-2">
                    {improvement >= 0 ? `+${improvement}` : improvement} pontos vs. último ciclo
                </p>
            </div>
        );
    };

    return (
    <Card className={cn(className, "flex flex-col")}>
      <CardHeader>
        <div className="flex items-center gap-2">
            <SmilePlus className="h-5 w-5 text-primary" />
            <CardTitle>NPS Interno</CardTitle>
        </div>
        <CardDescription>Satisfação dos colaboradores</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        {renderContent()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
        </CardFooter>
      )}
    </Card>
  );
}
