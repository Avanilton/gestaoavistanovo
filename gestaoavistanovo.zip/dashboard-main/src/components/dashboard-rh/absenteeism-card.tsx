
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CalendarOff, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { getAbsenteeismData } from "@/app/actions/rh-data-actions";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip, LabelList } from "recharts";
import { ChartContainer, ChartTooltipContent, ChartConfig } from "@/components/ui/chart";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type AbsenteeismData = {
    byDepartment: { name: string; value: number }[];
};

type AbsenteeismCardProps = {
  className?: string;
};

const chartConfig = {
  value: {
    label: "Taxa",
    color: "hsl(var(--chart-2))",
  },
} satisfies ChartConfig;


export function AbsenteeismCard({ className }: AbsenteeismCardProps) {
  const [data, setData] = useState<AbsenteeismData | undefined>(undefined);
  const [average, setAverage] = useState<number | null>(null);
  const [referenceMonth, setReferenceMonth] = useState<string | undefined>();
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());


  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getAbsenteeismData();
        if (result.error) {
          throw new Error(result.error);
        }
        
        const sortedData = result.data?.byDepartment.sort((a, b) => b.value - a.value);
        setData({ byDepartment: sortedData || [] });
        setReferenceMonth(result.referenceMonth);

        if (sortedData && sortedData.length > 0) {
            const total = sortedData.reduce((acc, item) => acc + item.value, 0);
            setAverage(total / sortedData.length);
        }

      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="h-[250px] w-full">
          <Skeleton className="h-full w-full" />
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[250px]">
          <AlertTriangle className="h-6 w-6 mb-2" />
          <p className="font-semibold">Erro ao carregar</p>
          <p className="text-xs">{error}</p>
        </div>
      );
    }
    
    if (!data || !data.byDepartment || data.byDepartment.length === 0) {
      return <p className="text-muted-foreground flex items-center justify-center h-full min-h-[250px]">Nenhum dado encontrado.</p>;
    }
    
    return (
      <ChartContainer config={chartConfig} className="h-[250px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart accessibilityLayer data={data.byDepartment} layout="vertical" margin={{ top: 5, right: 30, left: 10, bottom: 5 }}>
            <CartesianGrid horizontal={false} />
            <YAxis 
              dataKey="name"
              type="category"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              width={80}
              className="text-xs"
            />
            <XAxis type="number" unit="%" />
            <Tooltip content={<ChartTooltipContent />} cursor={{fill: 'hsl(var(--muted))'}} />
            <Bar dataKey="value" fill="var(--color-value)" radius={[0, 4, 4, 0]}>
                <LabelList
                    dataKey="value"
                    position="right"
                    offset={5}
                    className="fill-foreground"
                    fontSize={12}
                    formatter={(value: number) => `${value.toFixed(2)}%`}
                />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartContainer>
    );
  }

  return (
    <Card className={cn(className, "flex flex-col")}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarOff className="h-5 w-5 text-primary" />
            <CardTitle>Absenteísmo por Setor</CardTitle>
          </div>
        </div>
        <CardDescription>Taxa de ausências por departamento</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        {renderContent()}
      </CardContent>
      <CardFooter className="flex-col items-center pt-4 border-t">
        {average !== null && !isLoading && !error && (
            <div className="text-center mb-4">
            <p className="text-base text-muted-foreground">Média Geral</p>
            <p className="text-4xl font-bold text-primary">{average.toFixed(2)}%</p>
            </div>
        )}
        {!isLoading && (
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
        )}
      </CardFooter>
    </Card>
  );
}
