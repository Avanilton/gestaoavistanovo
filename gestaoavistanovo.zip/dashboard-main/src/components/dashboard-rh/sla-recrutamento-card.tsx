
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Users, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { getSlaRecrutamentoData } from "@/app/actions/rh-data-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type SlaData = {
  value: number;
};

type SlaRecrutamentoCardProps = {
  className?: string;
};

export function SlaRecrutamentoCard({ className }: SlaRecrutamentoCardProps) {
    const [data, setData] = useState<SlaData | undefined>(undefined);
    const [referenceMonth, setReferenceMonth] = useState<string | undefined>();
    const [error, setError] = useState<string | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(true);
    const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());
    
    useEffect(() => {
        async function fetchData() {
            try {
                setIsLoading(true);
                const result = await getSlaRecrutamentoData();
                if (result.error) {
                    throw new Error(result.error);
                }
                setData(result.data);
                setReferenceMonth(result.referenceMonth);
            } catch (e: any) {
                setError(e.message || "Ocorreu um erro desconhecido.");
            } finally {
                setIsLoading(false);
                setUpdateTimestamp(Date.now());
            }
        }
        fetchData();
    }, []);
    
    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center min-h-[120px]">
                    <Skeleton className="h-14 w-24 mb-2" />
                </div>
            );
        }

        if (error) {
            return (
                <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[120px]">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <p className="font-semibold">Erro ao carregar</p>
                    <p className="text-xs">{error}</p>
                </div>
            );
        }

        if (data === undefined) {
            return <p className="text-muted-foreground flex items-center justify-center min-h-[120px]">Nenhum dado encontrado.</p>;
        }
        
        return (
            <div className="flex flex-col items-center justify-center min-h-[120px]">
                <div className="text-6xl font-bold">{data.value.toFixed(2).replace('.', ',')}%</div>
            </div>
        );
    };

    return (
    <Card className={cn(className, "flex flex-col")}>
      <CardHeader>
        <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            <CardTitle>SLA Recrutamento</CardTitle>
        </div>
        <CardDescription>Percentual de vagas fechadas no prazo</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        {renderContent()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
        </CardFooter>
      )}
    </Card>
  );
}
