
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { DollarSign, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { getMarketingData, type SankhyaMarketingData } from "@/app/actions/sankhya-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";
import { format, parse } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function TicketMedioCard({ className }: { className?: string }) {
  const [data, setData] = useState<SankhyaMarketingData | undefined>(undefined);
  const [referenceMonth, setReferenceMonth] = useState<string | undefined>();
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());


  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getMarketingData();
        if (result.error) {
          setError(typeof result.error === 'string' ? result.error : JSON.stringify(result.error));
        } else if (result.data) {
          setData(result.data);
          if (result.data.periodo) {
            const date = parse(result.data.periodo, 'dd/MM/yyyy HH:mm:ss', new Date());
            setReferenceMonth(format(date, "MMMM / yyyy", { locale: ptBR }));
          }
        }
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

  const renderContent = () => {
    if (isLoading) {
      return <Skeleton className="h-12 w-32" />;
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center text-center text-destructive">
          <AlertTriangle className="h-6 w-6 mb-2" />
          <p className="text-xs">{error}</p>
        </div>
      );
    }
    
    if (!data) {
      return <p className="text-muted-foreground">Nenhum dado.</p>;
    }

    return (
      <div className="text-6xl font-bold">
        {data.tkMedio.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
      </div>
    );
  };

  return (
    <Card className={cn("flex flex-col", className)}>
      <CardHeader>
        <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <CardTitle>Ticket Médio</CardTitle>
        </div>
        <CardDescription>Valor médio por pedido (E-commerce)</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center justify-center">
        {renderContent()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
        </CardFooter>
      )}
    </Card>
  );
}
