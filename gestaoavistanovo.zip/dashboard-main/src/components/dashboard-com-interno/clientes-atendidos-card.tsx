
"use client";

export function ClientesAtendidosCard() {
  return null;
}
