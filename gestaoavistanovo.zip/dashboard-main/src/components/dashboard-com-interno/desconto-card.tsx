
"use client";

export function DescontoCard() {
  return null;
}
