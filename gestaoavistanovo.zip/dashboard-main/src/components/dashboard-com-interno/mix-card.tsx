
"use client";

export function MixCard() {
  return null;
}
