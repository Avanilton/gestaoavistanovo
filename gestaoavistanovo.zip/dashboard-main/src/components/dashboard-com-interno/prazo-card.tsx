
"use client";

export function PrazoCard() {
  return null;
}
