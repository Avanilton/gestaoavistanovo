
"use client";

export function MetaCard() {
  return null;
}
