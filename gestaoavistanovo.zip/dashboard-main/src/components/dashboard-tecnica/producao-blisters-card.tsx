
"use client";

import { useState } from "react";
import { BarChart3, Target } from "lucide-react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, LabelList, ReferenceLine } from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { ChartContainer, ChartConfig } from "@/components/ui/chart";
import { cn } from "@/lib/utils";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

export type BlisterProductionData = {
    month: string;
    production2024: number | null;
    production2025: number | null;
    production2026: number | null;
};

const chartConfig = {
  production2024: {
    label: "Produção 2024",
    color: "hsl(var(--chart-2))", // Azul
  },
  production2025: {
    label: "Produção 2025",
    color: "hsl(var(--chart-3))", // Laranja
  },
  production2026: {
    label: "Produção 2026",
    color: "hsl(var(--chart-1))", // Verde
  },
} satisfies ChartConfig;

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-background border border-border p-2 rounded-lg shadow-lg">
                <p className="label font-bold">{`${label}`}</p>
                {payload.map((pld: any, index: number) => (
                     <p key={index} style={{ color: pld.color }}>
                        {`${pld.name}: ${pld.value.toLocaleString('pt-BR')}`}
                    </p>
                ))}
            </div>
        );
    }
    return null;
};

export function ProducaoBlistersCard({ className }: { className?: string }) {
    // #region Valores Manuais
    // EDITAR AQUI: Insira o total de produção para cada ano.
    const total2024 = 110947;
    const total2025 = 204480;
    const total2026 = 23975;
    
    // EDITAR AQUI: Defina as metas anuais.
    const metaAnual2025 = 180000;
    const metaAnual2026 = 240000;

    // EDITAR AQUI: Insira os dados mensais para o gráfico.
    const data: BlisterProductionData[] = [
        { month: "Janeiro", production2024: 3340, production2025: 24080, production2026: 23975 },
        { month: "Fevereiro", production2024: 8020, production2025: 26307, production2026: null },
        { month: "Março", production2024: 12430, production2025: 13337, production2026: null },
        { month: "Abril", production2024: 10810, production2025: 12003, production2026: null },
        { month: "Maio", production2024: 6729, production2025: 15832, production2026: null },
        { month: "Junho", production2024: 11745, production2025: 17860, production2026: null },
        { month: "Julho", production2024: 15579, production2025: 14803, production2026: null },
        { month: "Agosto", production2024: 14240, production2025: 14678, production2026: null },
        { month: "Setembro", production2024: 4002, production2025: 16368, production2026: null },
        { month: "Outubro", production2024: 8262, production2025: 21586, production2026: null },
        { month: "Novembro", production2024: 15790, production2025: 19718, production2026: null },
        { month: "Dezembro", production2024: 300, production2025: 7908, production2026: null },
    ];
    // #endregion

    const percentualMeta2026 = metaAnual2026 > 0 ? (total2026 / metaAnual2026) * 100 : 0;
    const [updateTimestamp] = useState<number>(Date.now());

    const renderContent = () => {
        return (
            <ChartContainer config={chartConfig} className="h-[350px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                        data={data}
                        margin={{
                            top: 30, right: 30, left: 20, bottom: 5,
                        }}
                    >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis
                            dataKey="month"
                            tickLine={false}
                            axisLine={false}
                            tickMargin={8}
                            tickFormatter={(value) => value.slice(0, 3).toUpperCase()}
                        />
                        <YAxis
                            tickFormatter={(value) => new Intl.NumberFormat('pt-BR').format(value)}
                            width={80}
                            tickLine={false}
                            axisLine={false}
                        />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(var(--muted) / 0.5)' }} />
                        <Legend iconType="circle" />
                        
                        <ReferenceLine y={20000} label={{ value: "Meta", position: "insideTopRight", fill: "hsl(var(--destructive))", fontSize: 12 }} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
                        
                        <Bar dataKey="production2024" fill="var(--color-production2024)" name={chartConfig.production2024.label} radius={[4, 4, 0, 0]}>
                            <LabelList dataKey="production2024" position="top" formatter={(value: number) => value > 0 ? value.toLocaleString('pt-BR') : ''} fontSize={10} />
                        </Bar>
                        <Bar dataKey="production2025" fill="var(--color-production2025)" name={chartConfig.production2025.label} radius={[4, 4, 0, 0]}>
                            <LabelList dataKey="production2025" position="top" formatter={(value: number) => value > 0 ? value.toLocaleString('pt-BR') : ''} fontSize={10} />
                        </Bar>
                         <Bar dataKey="production2026" fill="var(--color-production2026)" name={chartConfig.production2026.label} radius={[4, 4, 0, 0]}>
                            <LabelList dataKey="production2026" position="top" formatter={(value: number) => value > 0 ? value.toLocaleString('pt-BR') : ''} fontSize={10} />
                        </Bar>

                    </BarChart>
                </ResponsiveContainer>
            </ChartContainer>
        );
    };

    return (
        <Card className={cn("col-span-1 lg:col-span-3", className)}>
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div className="flex-1">
                        <div className="flex items-center gap-2">
                            <BarChart3 className="h-5 w-5 text-primary" />
                            <CardTitle>Produção - Blister (Comparativo Anual)</CardTitle>
                        </div>
                         <CardDescription>Quantidade de blisters produzidos por mês.</CardDescription>
                    </div>
                    <div className="flex gap-6">
                        <Card className="p-4 text-center">
                            <CardDescription className="text-3xl">Total 2024</CardDescription>
                            <p className="text-7xl font-bold" style={{ color: chartConfig.production2024.color }}>{total2024.toLocaleString('pt-BR')}</p>
                            <div className="flex items-center justify-center gap-2 mt-2 text-xl text-muted-foreground">
                                <Target className="h-6 w-6 text-green-500" />
                                <span className="font-semibold">92,70% da meta</span>
                            </div>
                        </Card>
                         <Card className="p-4 text-center">
                            <CardDescription className="text-3xl">Total 2025</CardDescription>
                            <p className="text-7xl font-bold" style={{ color: chartConfig.production2025.color }}>{total2025.toLocaleString('pt-BR')}</p>
                            <div className="flex items-center justify-center gap-2 mt-2 text-xl text-muted-foreground">
                                <Target className="h-6 w-6 text-green-500" />
                                <span className="font-semibold">133,3% da meta</span>
                            </div>
                            <CardDescription className="text-lg mt-2">Meta Anual: {metaAnual2025.toLocaleString('pt-BR')}</CardDescription>
                        </Card>
                        <Card className="p-4 text-center">
                            <CardDescription className="text-3xl">Total 2026</CardDescription>
                            <p className="text-7xl font-bold" style={{ color: chartConfig.production2026.color }}>{total2026.toLocaleString('pt-BR')}</p>
                            <div className="flex items-center justify-center gap-2 mt-2 text-xl text-muted-foreground">
                                <Target className="h-6 w-6 text-green-500" />
                                <span className="font-semibold">{percentualMeta2026.toFixed(1).replace('.', ',')}% da meta</span>
                            </div>
                            <CardDescription className="text-lg mt-2">Meta Anual: {metaAnual2026.toLocaleString('pt-BR')}</CardDescription>
                        </Card>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                {renderContent()}
            </CardContent>
            <CardFooter className="p-0">
                <CardUpdateFooter updateTimestamp={updateTimestamp} />
            </CardFooter>
        </Card>
    );
}
