
"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { PackagePlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { CardUpdateFooter } from "../dashboard/card-update-footer";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend, LabelList } from "recharts";
import { ChartConfig, ChartContainer } from "@/components/ui/chart";

type MonthlyData = {
    month: string;
    percentage2025: number;
    percentage2026: number;
};

type ItensNovosCardProps = {
    className?: string;
};

const chartConfig = {
    percentage2025: {
        label: "2025",
        color: "hsl(var(--chart-2))", // Azul
    },
    percentage2026: {
        label: "2026",
        color: "hsl(var(--chart-3))", // Laranja
    },
} satisfies ChartConfig;

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-background border border-border p-2 rounded-lg shadow-lg text-sm">
                <p className="label font-bold">{label}</p>
                {payload.map((pld: any) => (
                    <p key={pld.dataKey} style={{ color: pld.color }}>
                        {`${pld.name}: ${pld.value.toFixed(2)}%`}
                    </p>
                ))}
            </div>
        );
    }
    return null;
};

export function ItensNovosCard({ className }: ItensNovosCardProps) {
    // #region Valores Manuais
    // EDITAR AQUI: Insira a média anual para cada ano.
    const annualAverage2025 = 2.3;
    const annualAverage2026 = 3.45;

    // EDITAR AQUI: Insira os dados mensais para o gráfico.
    const combinedData: MonthlyData[] = [
        { month: 'JAN', percentage2025: 0.89, percentage2026: 3.45  },
        { month: 'FEV', percentage2025: 0.83, percentage2026: 0 },
        { month: 'MAR', percentage2025: 1.53, percentage2026: 0},
        { month: 'ABR', percentage2025: 1.75, percentage2026: 0 },
        { month: 'MAI', percentage2025: 1.94, percentage2026: 0 },
        { month: 'JUN', percentage2025: 1.54, percentage2026: 0 },
        { month: 'JUL', percentage2025: 2.26, percentage2026: 0 },
        { month: 'AGO', percentage2025: 2.61, percentage2026: 0 },
        { month: 'SET', percentage2025: 3.51, percentage2026: 0 },
        { month: 'OUT', percentage2025: 3.45, percentage2026: 0 },
        { month: 'NOV', percentage2025: 4.13, percentage2026: 0 },
        { month: 'DEZ', percentage2025: 3.08, percentage2026: 0 },
    ];
    // #endregion

    const [updateTimestamp] = useState<number>(Date.now());

    const renderContent = () => {
        const displayData = combinedData.filter(d => d.percentage2025 > 0 || d.percentage2026 > 0);

        if (displayData.length === 0) {
            return (
                <div className="flex items-center justify-center text-muted-foreground min-h-[500px]">
                    Nenhum dado de item novo encontrado para os anos selecionados.
                </div>
            );
        }

        return (
            <ChartContainer config={chartConfig} className="h-[500px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                        data={displayData}
                        layout="vertical"
                        margin={{ top: 5, right: 60, left: 10, bottom: 5 }}
                        barCategoryGap="20%"
                    >
                        <CartesianGrid horizontal={false} />
                        <YAxis
                            dataKey="month"
                            type="category"
                            width={60}
                            tickLine={false}
                            axisLine={false}
                            tick={{ fontSize: 18 }}
                            interval={0}
                        />
                        <XAxis type="number" unit="%" tick={{ fontSize: 14 }} />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(var(--muted))' }} />
                        <Legend iconType="circle" />
                        <Bar dataKey="percentage2025" name="2025" fill="var(--color-percentage2025)" radius={[0, 4, 4, 0]}>
                           <LabelList dataKey="percentage2025" position="right" formatter={(value: number) => value > 0 ? `${value.toFixed(2)}%` : ''} fontSize={18} />
                        </Bar>
                        <Bar dataKey="percentage2026" name="2026" fill="var(--color-percentage2026)" radius={[0, 4, 4, 0]}>
                           <LabelList dataKey="percentage2026" position="right" formatter={(value: number) => value > 0 ? `${value.toFixed(2)}%` : ''} fontSize={18} />
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </ChartContainer>
        );
    };

    return (
        <Card className={cn("flex flex-col", className)}>
            <CardHeader>
                <div className="flex items-center justify-between">
                     <div className="flex items-center gap-2">
                        <PackagePlus className="h-5 w-5 text-primary" />
                        <CardTitle>Ítens Novos (2025 vs 2026)</CardTitle>
                    </div>
                    <div className="flex gap-4">
                        <div className="text-center">
                            <p className="text-sm font-medium text-muted-foreground">Média Anual 2025</p>
                            <p className="text-3xl font-bold" style={{ color: chartConfig.percentage2025.color }}>{annualAverage2025.toFixed(2)}%</p>
                        </div>
                        <div className="text-center">
                            <p className="text-sm font-medium text-muted-foreground">Média Anual 2026</p>
                            <p className="text-3xl font-bold" style={{ color: chartConfig.percentage2026.color }}>{annualAverage2026.toFixed(2)}%</p>
                        </div>
                    </div>
                </div>
                <CardDescription>Percentual de vendas de itens novos.</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
                {renderContent()}
            </CardContent>
            <CardFooter className="p-0">
                <CardUpdateFooter updateTimestamp={updateTimestamp} />
            </CardFooter>
        </Card>
    );
}
