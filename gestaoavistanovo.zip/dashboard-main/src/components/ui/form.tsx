"use client";

const Form = () => null;
const FormItem = () => null;
const FormLabel = () => null;
const FormControl = () => null;
const FormDescription = () => null;
const FormMessage = () => null;
const FormField = () => null;

export {
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  FormField,
};
