
"use client";

import * as React from "react";

export function Carousel({ children }: { children?: React.ReactNode }) {
  return <div className="hidden">{children}</div>;
}

export function CarouselContent({ children }: { children?: React.ReactNode }) {
  return <div className="hidden">{children}</div>;
}

export function CarouselItem({ children }: { children?: React.ReactNode }) {
  return <div className="hidden">{children}</div>;
}

export function CarouselPrevious() {
  return null;
}

export function CarouselNext() {
  return null;
}

export type CarouselApi = any;
