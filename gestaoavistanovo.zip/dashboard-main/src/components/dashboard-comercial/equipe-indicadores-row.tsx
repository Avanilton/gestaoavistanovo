
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Percent, CalendarClock, ShoppingBasket, Users, Target } from "lucide-react";
import { cn } from "@/lib/utils";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { CardUpdateFooter } from "../dashboard/card-update-footer";
import { ChartContainer, ChartTooltipContent, ChartConfig } from "@/components/ui/chart";

type EquipeIndicadoresRowProps = {
    title: string;
    percentual: number;
    dm: number;
    pmf: number;
    mix: number;
    clientesAtendidos: number;
    updateTimestamp: number;
    referenceMonth?: string;
    className?: string;
}

const getMetaColor = (value: number) => {
    if (value > 90) return { color: 'text-green-500', fill: 'hsl(var(--chart-1))' };
    if (value > 75) return { color: 'text-blue-500', fill: 'hsl(var(--chart-2))' };
    if (value > 50) return { color: 'text-yellow-500', fill: 'hsl(var(--chart-6))' };
    return { color: 'text-red-500', fill: 'hsl(var(--chart-4))' };
};


function MetaCard({ value }: { value: number }) {
    const { color, fill } = getMetaColor(value);
    
    const chartData = [
        { name: 'atingido', value: value, fill: fill },
        { name: 'faltante', value: 100 - value, fill: 'hsl(var(--muted))' },
    ];
    
    const chartConfig = {
      atingido: {
        label: "Atingido",
        color: fill,
      },
      faltante: {
        label: "Faltante",
        color: "hsl(var(--muted))",
      }
    } satisfies ChartConfig;


    return (
        <Card className="flex flex-col">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><Target className="h-6 w-6" /> Meta</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex items-center justify-center">
                 <div className="w-40 h-40 relative">
                    <ChartContainer config={chartConfig} className="w-full h-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Tooltip
                                    cursor={{fill: 'transparent'}}
                                    content={<ChartTooltipContent hideLabel formatter={(value, name) => [`${(value as number).toFixed(2)}%`, chartConfig[name as keyof typeof chartConfig]?.label ?? name]} />}
                                />
                                <Pie data={chartData} dataKey="value" nameKey="name" innerRadius="70%" outerRadius="100%" startAngle={90} endAngle={-270} stroke="none">
                                {chartData.map((entry) => (
                                    <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                                ))}
                                </Pie>
                            </PieChart>
                        </ResponsiveContainer>
                    </ChartContainer>
                     <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                         <span className={cn("text-3xl font-bold", color)}>
                            {value.toFixed(2)}%
                        </span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

function IndicadorCard({ icon, title, value, unit }: { icon: React.ReactNode, title: string, value: string | number, unit?: string }) {
    return (
        <Card className="flex flex-col">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">{icon} {title}</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex items-center justify-center">
                <p className="text-5xl font-bold">{value}{unit}</p>
            </CardContent>
        </Card>
    );
}

export function EquipeIndicadoresRow({ 
    title, 
    percentual,
    dm,
    pmf,
    mix,
    clientesAtendidos,
    updateTimestamp, 
    referenceMonth,
    className 
}: EquipeIndicadoresRowProps) {

    return (
        <Card className={cn("w-full", className)}>
            <CardHeader>
                <CardTitle className="text-3xl">{title}</CardTitle>
                <CardDescription className="text-base">Indicadores de performance da equipe</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    <MetaCard value={percentual} />
                    <IndicadorCard icon={<Percent className="h-6 w-6" />} title="Desc. Médio" value={dm.toFixed(2)} unit="%" />
                    <IndicadorCard icon={<CalendarClock className="h-6 w-6" />} title="Prazo Médio" value={pmf.toFixed(2)} />
                    <IndicadorCard icon={<ShoppingBasket className="h-6 w-6" />} title="Mix Produtos" value={mix.toFixed(2)} unit="%" />
                    <IndicadorCard icon={<Users className="h-6 w-6" />} title="Clientes Atend." value={clientesAtendidos} />
                </div>
            </CardContent>
            <CardFooter className="p-0">
                <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={referenceMonth} />
            </CardFooter>
        </Card>
    );
}
