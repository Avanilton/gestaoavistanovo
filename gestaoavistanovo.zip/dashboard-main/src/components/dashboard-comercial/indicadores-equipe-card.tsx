"use client";

export default function IndicadoresEquipeCard() {
  return null;
}
