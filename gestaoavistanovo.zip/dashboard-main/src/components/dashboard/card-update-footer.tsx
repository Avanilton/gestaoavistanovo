
"use client";

import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useState, useEffect } from "react";

type CardUpdateFooterProps = {
  updateTimestamp: number;
  className?: string;
  referenceMonth?: string; // Espera um formato como "MM/YYYY", "dd/MM/yyyy HH:mm:ss" ou um nome de mês
};

export function CardUpdateFooter({ updateTimestamp, className, referenceMonth }: CardUpdateFooterProps) {
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [month, setMonth] = useState<string>('');

  useEffect(() => {
    setLastUpdated(format(new Date(updateTimestamp), "dd/MM/yyyy 'às' HH:mm:ss", { locale: ptBR }));

    if (referenceMonth) {
        setMonth(referenceMonth);
    } else {
        setMonth(format(new Date(), "MMMM", { locale: ptBR }));
    }

  }, [updateTimestamp, referenceMonth]);

  return (
    <div className={cn("text-xs text-muted-foreground pt-2 text-center border-t mt-4", className)}>
      {month && <p>Mês de referência: <span className="font-semibold capitalize">{month}</span></p>}
      {lastUpdated ? (
        <p>Última atualização: {lastUpdated}</p>
      ) : (
        <p>Verificando atualização...</p>
      )}
    </div>
  );
}
