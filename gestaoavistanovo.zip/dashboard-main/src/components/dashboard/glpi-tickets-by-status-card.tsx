"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Ticket, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { getTicketsByStatus, type TicketStatusCount } from "@/app/actions/glpi-data-actions";
import { Skeleton } from "@/components/ui/skeleton";
import { CardUpdateFooter } from "./card-update-footer";

type GlpiTicketsByStatusCardProps = {
  className?: string;
};

export function GlpiTicketsByStatusCard({ className }: GlpiTicketsByStatusCardProps) {
  const [data, setData] = useState<TicketStatusCount[] | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getTicketsByStatus();
        if (result.error) {
          setError(result.error);
        } else {
          setData(result.data);
        }
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[...Array(4)].map((_, index) => (
            <Card key={index} className="p-4">
              <Skeleton className="h-7 w-1/2 mb-2" />
              <Skeleton className="h-4 w-1/3" />
            </Card>
          ))}
        </div>
      );
    }
    
    if (error) {
        return (
            <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[120px]">
                <AlertTriangle className="h-6 w-6 mb-2" />
                <p className="font-semibold">Falha ao carregar dados</p>
                <p className="text-xs">{error}</p>
            </div>
        );
    }

    if (!data || data.length === 0) {
      return (
        <div className="flex h-[100px] items-center justify-center text-muted-foreground">
          Nenhum chamado ativo encontrado no GLPI.
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {data.map((status) => (
          <Card 
            key={status.status} 
            className="p-4 flex flex-col items-center justify-center text-center transition-transform hover:scale-105"
            style={{ 
              backgroundColor: status.fill,
              color: status.textColor || 'inherit'
            }}
          >
            <p className="text-5xl font-bold">{status.count}</p>
            <p className="text-base font-semibold break-words">{status.status}</p>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <Card className={cn("flex flex-col", className)}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Ticket className="h-5 w-5 text-primary" />
          <CardTitle>Chamados por Status (GLPI)</CardTitle>
        </div>
        <CardDescription>Visão geral da quantidade de chamados em cada status</CardDescription>
      </CardHeader>
      <CardContent className="min-h-[120px]">
        {renderContent()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} />
        </CardFooter>
      )}
    </Card>
  );
}
