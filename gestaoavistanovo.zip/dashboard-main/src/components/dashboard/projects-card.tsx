"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getProjectsData, type ProjectData } from "@/app/actions/glpi-data-actions";
import { cn } from "@/lib/utils";
import { Briefcase, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { CardUpdateFooter } from "./card-update-footer";

type PriorityConfig = {
  label: string;
  className: string;
};

const priorityMap: { [key: number]: PriorityConfig } = {
  6: { label: "Crítico", className: "bg-red-600 text-white" },
  5: { label: "Muito Alta", className: "bg-blue-800 text-white" },
  4: { label: "Alta", className: "bg-blue-500 text-white" },
  3: { label: "Média", className: "bg-yellow-500 text-black" },
  2: { label: "Baixa", className: "bg-green-700 text-white" },
  1: { label: "Muito Baixa", className: "bg-green-500 text-white" },
};

const getPriorityConfig = (priority: number): PriorityConfig => {
  return priorityMap[priority] || { label: "N/D", className: "bg-gray-400 text-white" };
};

type ProjectsCardProps = {
  className?: string;
};

export function ProjectsCard({ className }: ProjectsCardProps) {
  const [data, setData] = useState<ProjectData[] | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getProjectsData();
        if (result.error) {
          setError(result.error);
        } else {
          setData(result.data);
        }
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

  const projectsData = data || [];
  const projectCount = projectsData.length;

  const renderContent = () => {
    if (isLoading) {
       return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome do Projeto</TableHead>
              <TableHead>Andamento</TableHead>
              <TableHead className="text-right">Prioridade</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {[...Array(3)].map((_, i) => (
              <TableRow key={i}>
                <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                <TableCell className="text-right"><Skeleton className="h-6 w-20 ml-auto rounded-full" /></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[150px]">
          <AlertTriangle className="h-6 w-6 mb-2" />
          <p className="font-semibold">{error}</p>
        </div>
      );
    }
    
    if (projectsData.length === 0) {
      return (
        <div className="flex h-full min-h-[150px] items-center justify-center text-muted-foreground">
          Nenhum projeto em andamento encontrado.
        </div>
      );
    }

    return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome do Projeto</TableHead>
              <TableHead>Andamento</TableHead>
              <TableHead className="text-right">Prioridade</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projectsData.map((project) => {
               const priorityConfig = getPriorityConfig(project.priority);
               return (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium text-lg">{project.name}</TableCell>
                    <TableCell>
                        <div className="flex items-center gap-2">
                           <Progress value={project.percentDone} className="w-[60%]" />
                           <span className="text-sm text-muted-foreground">{project.percentDone}%</span>
                        </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge className={cn("border-transparent text-sm", priorityConfig.className)}>
                        {priorityConfig.label}
                      </Badge>
                    </TableCell>
                  </TableRow>
               );
            })}
          </TableBody>
        </Table>
    );
  };
  
  return (
    <Card className={cn("flex flex-col", className)}>
       <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Briefcase className="h-5 w-5 text-primary" />
            <CardTitle>Projetos em Andamento</CardTitle>
          </div>
          {!isLoading && !error && (
            <div className="text-4xl font-bold text-primary">{projectCount}</div>
          )}
        </div>
        <CardDescription>Projetos de TI atuais ordenados por prioridade (GLPI)</CardDescription>
      </CardHeader>
      <CardContent>
        {renderContent()}
      </CardContent>
      {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} />
        </CardFooter>
      )}
    </Card>
  );
}
