
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type DataSourceLabelProps = {
  source: string;
  className?: string;
};

export function DataSourceLabel({ source, className }: DataSourceLabelProps) {
  return (
    <div className={cn("flex justify-end", className)}>
      <Badge variant="outline" className="text-xs">
        Fonte de Dados: {source}
      </Badge>
    </div>
  );
}
