"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { getSlaDataFromGlpi, type SlaData } from "@/app/actions/glpi-data-actions";
import { Gauge, AlertTriangle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { CardUpdateFooter } from "./card-update-footer";

const getChartColor = (value: number) => {
    if (value <= 25) return 'hsl(var(--chart-4))'; // Vermelho
    if (value <= 50) return 'hsl(var(--chart-6))'; // Laranja/Ambar
    if (value <= 75) return 'hsl(var(--chart-6))'; // Amarelo
    return 'hsl(var(--chart-1))'; // Verde
};

type SlaAtendimentosCardProps = {
  className?: string;
};

export function SlaAtendimentosCard({ className }: SlaAtendimentosCardProps) {
  const [data, setData] = useState<SlaData | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getSlaDataFromGlpi();
        if (result.error) {
          setError(result.error);
        } else {
          setData(result.data);
        }
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

    const renderContent = () => {
        if (isLoading) {
            return <Skeleton className="h-[150px] w-full" />;
        }
        
        if (error) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-destructive text-center">
                    <AlertTriangle className="h-8 w-8 mb-2" />
                    <p className="font-semibold">Erro no Card de SLA</p>
                    <p className="text-xs break-words">{error}</p>
                </div>
            );
        }
        
        if (!data || data.ticketCount === 0) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                    <CheckCircle2 className="h-8 w-8 mb-2 text-green-500"/>
                    <p className="font-semibold">Nenhum chamado solucionado</p>
                    <p className="text-xs">100% de SLA (0 chamados no mês)</p>
                </div>
            );
        }

        const chartColor = getChartColor(data.value);

        return (
            <div className="w-full h-full flex flex-col items-center justify-center">
                <div className="flex flex-col items-center justify-center">
                    <span className="text-7xl font-bold" style={{ color: chartColor }}>
                        {data.value}%
                    </span>
                    <span className="text-lg text-muted-foreground mt-1">
                        SLA de Atendimentos
                    </span>
                </div>
            </div>
        );
    }
    
    return (
        <Card className={cn("flex flex-col", className)}>
            <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                    <Gauge className="h-5 w-5 text-primary" />
                    <CardTitle>SLA de Atendimentos (GLPI)</CardTitle>
                </div>
                <CardDescription>Chamados solucionados no prazo no mês de Dezembro (Meta 95%)</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col items-center justify-center pt-4 min-h-[250px]">
                 {renderContent()}
            </CardContent>
            {!isLoading && (
              <CardFooter className="p-0">
                  <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth="Dezembro" />
              </CardFooter>
            )}
        </Card>
    );
}
