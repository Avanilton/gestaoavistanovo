"use client";

import { useEffect } from "react";
import { usePageSwitcher } from "@/contexts/page-switcher-context";
import { usePathname } from 'next/navigation';

export function AutoPageSwitcher() {
  const { setCurrentPage } = usePageSwitcher();
  const pathname = usePathname();

  useEffect(() => {
    setCurrentPage(pathname);
  }, [pathname, setCurrentPage]);

  return null;
}
