
"use client";

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { BarChart3, Settings, LogOut, Loader, RefreshCw, ArrowRightLeft, ChevronDown, Play, Pause } from "lucide-react";
import { usePageSwitcher } from '@/contexts/page-switcher-context';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const navLinks = [
    { href: '/dashboard-ti', label: 'Dashboard TI' },
    { href: '/dashboard-logistica', label: 'Dashboard Logística' },
    { href: '/dashboard-rh', label: 'Dashboard RH' },
    { href: '/dashboard-pos-vendas', label: 'Pós Vendas' },
    { href: '/dashboard-mkt', label: 'Dashboard MKT' },
    { href: '/dashboard-comercial', label: 'Dashboard Comercial' },
    { href: '/dashboard-financeiro', label: 'Dashboard Financeiro' },
    { href: '/dashboard-tecnica', label: 'Dashboard Técnica' },
    { href: '/dashboard-comex', label: 'Dashboard Comex' },
    { href: '/dashboard-liga-decorlux', label: 'Liga Decorlux' },
    { href: '/dashboard-diversos', label: 'Diversos' },
];

export function Header() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const pathname = usePathname();
  const { isPaused, togglePause } = usePageSwitcher();

  const handleRefresh = () => {
    setIsRefreshing(true);
    window.location.reload(); 
    setTimeout(() => setIsRefreshing(false), 1000); 
  };
  
  const currentPage = navLinks.find(link => link.href === pathname);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
      <div className="flex items-center gap-2">
        <BarChart3 className="h-6 w-6 text-primary" />
        <Link href="/" className="text-xl font-bold tracking-tight hover:text-primary transition-colors">
            <h1>Gestão a Vista</h1>
        </Link>
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={togglePause} className="h-8 w-8 text-primary hover:bg-primary/10 hover:text-primary">
                        {isPaused ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
                        <span className="sr-only">{isPaused ? 'Iniciar' : 'Pausar'} rotação automática</span>
                    </Button>
                </TooltipTrigger>
                <TooltipContent>
                    <p>{isPaused ? 'Iniciar' : 'Pausar'} rotação automática</p>
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
      </div>

      <nav className="flex items-center gap-4 ml-4">
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 hover:text-primary">
                    <ArrowRightLeft className="mr-2 h-4 w-4" />
                     <span>{currentPage?.label || "Navegar"}</span>
                    <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="max-h-[80vh] overflow-y-auto">
                <DropdownMenuLabel>Ir para</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {navLinks.map(link => (
                    <Link href={link.href} key={link.href} passHref>
                        <DropdownMenuItem disabled={pathname === link.href}>
                            {link.label}
                        </DropdownMenuItem>
                    </Link>
                ))}
            </DropdownMenuContent>
        </DropdownMenu>
      </nav>

      <div className="ml-auto flex items-center gap-4">
         <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing} className="border-primary text-primary hover:bg-primary/10 hover:text-primary">
          {isRefreshing ? (
            <Loader className="mr-2 h-4 animate-spin" />
          ) : (
            <RefreshCw className="mr-2 h-4 w-4" />
          )}
          Atualizar Dados
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="overflow-hidden rounded-full"
            >
              <Avatar className="h-9 w-9">
                <AvatarFallback>TI</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <Settings className="mr-2 h-4 w-4" />
              <span>Configurações</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Sair</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
