
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { CheckCircle, XCircle, AlertTriangle, ListChecks, Percent } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { getAprovacoesData, type AprovacoesData } from "@/app/actions/sankhya-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type MetricCardProps = {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  isLoading: boolean;
  className?: string;
};

function MetricCard({ title, value, icon, isLoading, className }: MetricCardProps) {
    if (isLoading) {
        return (
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-xl font-medium">{title}</CardTitle>
                    <Skeleton className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-10 w-24" />
                </CardContent>
            </Card>
        );
    }
    return (
        <Card className={className}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-xl font-medium">{title}</CardTitle>
                {icon}
            </CardHeader>
            <CardContent>
                <div className="text-5xl font-bold">{value}</div>
            </CardContent>
        </Card>
    );
}

export function AprovacoesCard({ className }: { className?: string }) {
  const [data, setData] = useState<AprovacoesData | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getAprovacoesData();
        if (result.error) setError(typeof result.error === 'string' ? result.error : JSON.stringify(result.error));
        else setData(result.data);
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

  return (
    <Card className={cn("w-full flex flex-col", className)}>
       <CardHeader>
            <div className="flex items-center gap-2">
                <ListChecks className="h-5 w-5 text-primary" />
                <CardTitle>Aprovações x Reprovações</CardTitle>
            </div>
            <CardDescription>Status de aprovações de lançamentos financeiros</CardDescription>
        </CardHeader>
        <CardContent className="flex-1">
            {error ? (
                <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[120px]">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <p className="font-semibold">Falha ao carregar dados</p>
                    <p className="text-xs">{error}</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    <MetricCard 
                        title="Total de Lançamentos"
                        value={data?.total ?? 0}
                        icon={<ListChecks className="h-4 w-4 text-muted-foreground" />}
                        isLoading={isLoading}
                        className="lg:col-span-1"
                    />
                    <MetricCard 
                        title="Aprovados"
                        value={data?.aprovados ?? 0}
                        icon={<CheckCircle className="h-4 w-4 text-green-500" />}
                        isLoading={isLoading}
                    />
                    <MetricCard 
                        title="Reprovados"
                        value={data?.reprovados ?? 0}
                        icon={<XCircle className="h-4 w-4 text-red-500" />}
                        isLoading={isLoading}
                    />
                     <MetricCard 
                        title="% Aprovação"
                        value={`${data?.percentualAprovados.toFixed(2) ?? '0.00'}%`}
                        icon={<Percent className="h-4 w-4 text-green-500" />}
                        isLoading={isLoading}
                        className="border-green-500/50"
                    />
                     <MetricCard 
                        title="% Reprovação"
                        value={`${data?.percentualReprovados.toFixed(2) ?? '0.00'}%`}
                        icon={<Percent className="h-4 w-4 text-red-500" />}
                        isLoading={isLoading}
                        className="border-red-500/50"
                    />
                </div>
            )}
        </CardContent>
         {!isLoading && (
            <CardFooter className="p-0">
                <CardUpdateFooter updateTimestamp={updateTimestamp} />
            </CardFooter>
        )}
    </Card>
  );
}
