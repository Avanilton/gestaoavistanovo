
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Percent, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { getInadimplenciaData, type InadimplenciaData } from "@/app/actions/financeiro-data-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type MetricCardProps = {
  title: string;
  value: string;
  isLoading: boolean;
};

function MetricCard({ title, value, isLoading }: MetricCardProps) {
    if (isLoading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-28" />
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-14 w-24" />
                </CardContent>
            </Card>
        );
    }
    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-xl font-medium">{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-6xl font-bold">{value}</p>
            </CardContent>
        </Card>
    );
}


export function InadimplenciaCard({ className }: { className?: string }) {
  const [data, setData] = useState<InadimplenciaData | undefined>(undefined);
  const [error, setError] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [updateTimestamp, setUpdateTimestamp] = useState<number>(Date.now());


  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const result = await getInadimplenciaData();
        if (result.error) setError(result.error);
        else setData(result.data);
      } catch (e: any) {
        setError(e.message || "Ocorreu um erro desconhecido.");
      } finally {
        setIsLoading(false);
        setUpdateTimestamp(Date.now());
      }
    }
    fetchData();
  }, []);

  return (
    <Card className={cn("w-full flex flex-col", className)}>
       <CardHeader>
            <div className="flex items-center gap-2">
                <Percent className="h-5 w-5 text-primary" />
                <CardTitle>Inadimplência</CardTitle>
            </div>
            <CardDescription>Índices de inadimplência</CardDescription>
        </CardHeader>
        <CardContent className="flex-1">
            {error ? (
                <div className="flex flex-col items-center justify-center text-center text-destructive h-full min-h-[120px]">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <p className="font-semibold">Falha ao carregar dados</p>
                    <p className="text-xs">{error}</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    <MetricCard title="Geral" value={data?.geral ?? '...'} isLoading={isLoading} />
                    <MetricCard title="Externo" value={data?.externo ?? '...'} isLoading={isLoading} />
                    <MetricCard title="Interno" value={data?.interno ?? '...'} isLoading={isLoading} />
                    <MetricCard title="Bronze" value={data?.bronze ?? '...'} isLoading={isLoading} />
                    <MetricCard title="Acumulado 12M" value={data?.acumulado12M ?? '...'} isLoading={isLoading} />
                </div>
            )}
        </CardContent>
         {!isLoading && (
            <CardFooter className="p-0">
                <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={data?.mesReferencia} />
            </CardFooter>
        )}
    </Card>
  );
}
