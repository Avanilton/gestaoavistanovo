
"use client";

export function EquipeCard() {
  return null;
}
