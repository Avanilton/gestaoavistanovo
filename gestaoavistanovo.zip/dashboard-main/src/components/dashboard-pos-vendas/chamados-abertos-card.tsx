
"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Inbox, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import type { PosVendasSankhyaData } from "@/app/actions/pos-vendas-data-actions";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type ChamadosAbertosCardProps = {
  className?: string;
  initialData?: PosVendasSankhyaData;
  error?: string;
};

export function ChamadosAbertosCard({ className, initialData, error: initialError }: ChamadosAbertosCardProps) {
  const [data] = useState<PosVendasSankhyaData | undefined>(initialData);
  const [error] = useState<string | undefined>(initialError);
  const [isLoading] = useState(!initialData && !initialError);
  const [updateTimestamp] = useState<number>(Date.now());

  const renderContent = () => {
    if (isLoading) {
      return (
        <Skeleton className="h-20 w-24" />
      );
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center text-center">
            <AlertTriangle className="h-8 w-8 text-destructive mb-2" />
            <p className="text-center text-base font-semibold text-destructive">Falha ao Carregar</p>
            <p className="text-center text-xs text-destructive">{error}</p>
        </div>
      );
    }
    
    if (data === undefined) {
        return <p className="text-muted-foreground">Nenhum dado disponível.</p>
    }

    return (
        <div className="text-7xl font-bold">{data.chamadosAbertos}</div>
    );
  }

  return (
    <Card className={cn(className, "flex flex-col")}>
      <CardHeader>
        <div className="flex items-center gap-2">
            <Inbox className="h-5 w-5 text-primary" />
            <CardTitle>Chamados em Aberto</CardTitle>
        </div>
        <CardDescription>Total de processos pendentes</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center justify-center">
        {renderContent()}
      </CardContent>
      {!isLoading && (
        <CardFooter className="p-0">
          <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={data?.mesReferencia} />
        </CardFooter>
      )}
    </Card>
  );
}
