"use client";

import { useState, useEffect } from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip, LabelList } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { AlertCircle, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { PosVendasSankhyaData } from "@/app/actions/pos-vendas-data-actions";
import { Skeleton } from '@/components/ui/skeleton';
import { ChartContainer, ChartTooltipContent, ChartConfig } from "@/components/ui/chart";
import { CardUpdateFooter } from "../dashboard/card-update-footer";

type OcorrenciasPorSetorCardProps = {
  className?: string;
  initialData?: PosVendasSankhyaData;
  error?: string;
};

const chartConfig = {
  value: {
    label: "Ocorrências",
    color: "hsl(var(--chart-4))",
  },
} satisfies ChartConfig;

export function OcorrenciasPorSetorCard({ className, initialData, error: initialError }: OcorrenciasPorSetorCardProps) {
  const [data, setData] = useState<PosVendasSankhyaData | undefined>(undefined);
  const [error] = useState<string | undefined>(initialError);
  const [isLoading] = useState(!initialData && !initialError);
  const [updateTimestamp] = useState<number>(Date.now());


  useEffect(() => {
    if (initialData) {
      const sortedData = { ...initialData };
      if (sortedData?.ocorrenciasPorSetor) {
        sortedData.ocorrenciasPorSetor.sort((a, b) => b.value - a.value);
      }
      setData(sortedData);
    }
  }, [initialData]);
  
  const renderBody = () => {
    if (isLoading) {
        return <Skeleton className="h-[250px] w-full" />;
    }

    if (error) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-destructive text-center">
                <AlertTriangle className="h-8 w-8 mb-2" />
                <p className="font-semibold">Falha ao Carregar Dados</p>
                <p className="text-xs">{error}</p>
            </div>
        );
    }
    
    if (!data || !data.ocorrenciasPorSetor || data.ocorrenciasPorSetor.length === 0) {
        return <p className="flex items-center justify-center h-[250px] text-muted-foreground">Nenhum dado encontrado.</p>;
    }

    return (
      <ChartContainer config={chartConfig} className="h-[350px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data.ocorrenciasPorSetor} layout="vertical" margin={{ left: 10, right: 40 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} />
            <XAxis type="number" />
            <YAxis dataKey="name" type="category" width={100} tickLine={false} axisLine={false} tick={{ fontSize: 16 }} />
            <Tooltip content={<ChartTooltipContent />} cursor={{ fill: 'hsl(var(--muted))' }} />
            <Bar dataKey="value" fill="var(--color-value)" radius={[0, 4, 4, 0]}>
                <LabelList
                    dataKey="value"
                    position="right"
                    offset={5}
                    className="fill-foreground"
                    fontSize={25}
                />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartContainer>
    );
  };
  
  return (
    <Card className={cn(className, "flex flex-col")}>
      <CardHeader>
        <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-primary" />
            <CardTitle>Ocorrências por Setor</CardTitle>
        </div>
        <CardDescription>Distribuição de ocorrências que geraram chamados</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
       {renderBody()}
      </CardContent>
       {!isLoading && (
        <CardFooter className="p-0">
            <CardUpdateFooter updateTimestamp={updateTimestamp} referenceMonth={data?.mesReferencia} />
        </CardFooter>
      )}
    </Card>
  );
}
